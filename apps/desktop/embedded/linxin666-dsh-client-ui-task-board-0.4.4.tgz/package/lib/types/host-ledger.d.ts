import { type ExecutionOutcome, type ExecutionRecord, type TaskRecord } from './core/tasks.ts';
import { type TaskBoardAction, type TaskBoardSchedulerSnapshot } from './protocol.ts';
import { type TaskPermission } from './core/handover.ts';
export interface LedgerState {
    revision: number;
    tasks: TaskRecord[];
    scheduler: TaskBoardSchedulerSnapshot;
}
export interface OpenedRun {
    task: TaskRecord;
    execution: ExecutionRecord;
    /**
     * How the Host obtains this run's session. Absent or `session` launches a
     * fresh (or reused) execution session; `teammate` means the run belongs to a
     * team-mode cascade, where the Host asks the root's Lead session to spawn a
     * teammate instead of launching a session of its own.
     */
    dispatch?: 'session' | 'teammate';
}
/** Minimal value copy used by the Host session monitor. */
export interface OpenExecutionReference {
    readonly taskId: string;
    readonly executionId: string;
    readonly sessionId: string | undefined;
    readonly startedAt: number;
    /**
     * True for a member of a team-mode run other than its Lead. A teammate is a
     * durable member of the Team: it stays alive after its turn ends, so the
     * roster may keep reporting its session as running, and the turn it completed
     * is the only verdict it exposes.
     */
    readonly teamMember: boolean;
}
/** Minimal value copy used by the Host scheduler. */
export interface DueScheduleReference {
    readonly taskId: string;
    readonly cron: string;
    /** Zone this rule's wall clock is read in. */
    readonly timeZone: string;
    readonly nextRunAt: number;
}
/** Derived runtime data for one session-poll pass. */
export interface LedgerRuntimeView {
    readonly armedSchedules: number;
    readonly openExecutions: readonly OpenExecutionReference[];
}
/**
 * Best-effort single-letter process state ('R','S','D','Z',...) or undefined
 * when no probe is available on this platform. Linux reads /proc/<pid>/stat
 * directly (no subprocess); other POSIX shells out to `ps -o stat=`; Windows
 * has no zombie state, so it returns undefined and the kill(0) probe alone
 * is authoritative there.
 */
export declare function processState(pid: number): string | undefined;
export declare function processIsAlive(pid: number): boolean;
/** Runs one PowerShell script and returns its trimmed stdout. */
export type PowerShellProbe = (script: string, timeoutMs: number) => string | undefined;
/**
 * Windows start time (Unix epoch ms) of a live process.
 *
 * `Get-Process` is the precise first choice, but an unprivileged caller cannot
 * read `.StartTime` for a protected process (System, svchost): the property is
 * empty, so the probe returns nothing. Without a fallback, a crash leftover
 * lock whose PID was reused by such a process could never be proven stale and
 * blocked every startup until the lock was deleted by hand (issue #1629).
 * Win32_Process through CIM reports the same CreationDate for those processes
 * at the same millisecond precision, so it is the second identity source. The
 * probe is injectable so the fallback chain is testable off Windows.
 */
export declare function win32StartTimeMs(pid: number, probe?: PowerShellProbe): number | undefined;
/**
 * Repair parent links after a load or an import: a link whose parent row is
 * missing, cyclic, or names an archived parent while the child is on board is
 * dropped (the task becomes a root) instead of dropping the task. A chain
 * deeper than the current `maxSubtaskDepth` is deliberately KEPT: the limit
 * gates new links, it never deletes a stored one, and every cascade walk is
 * bounded by the limit anyway. The Host is the only writer of these links, so
 * this is a last-resort guard against a hand-edited or imported document.
 */
export declare function repairParentLinks(tasks: readonly TaskRecord[]): TaskRecord[];
export declare class HostTaskLedger {
    private readonly now;
    private document;
    private readonly listeners;
    private readonly requestCache;
    private readonly lockToken;
    private lockFd;
    readonly file: string;
    readonly lockFile: string;
    /** Small sidecar for the 30 s scheduler heartbeat (lastTickAt only). */
    readonly schedulerFile: string;
    /** Session-default permission the confirmation gate compares against. */
    readonly sessionDefaultPermission: TaskPermission;
    /**
     * Deployment subtask depth limit (1..3): the lineage gate every write obeys.
     * The settings card edits it live, so {@link setMaxSubtaskDepth} mutates it
     * instead of remounting the row.
     */
    private depthLimit;
    constructor(dir?: string, now?: () => number, options?: {
        sessionDefaultPermission?: TaskPermission;
        maxSubtaskDepth?: number;
    });
    /** Current subtask depth limit (1..3). */
    get maxSubtaskDepth(): number;
    /**
     * Apply a live settings edit of the subtask depth limit. A no-op when the
     * normalized limit is unchanged, so a coarse volatile invalidation that
     * changed nothing emits nothing.
     */
    setMaxSubtaskDepth(depth: number): void;
    /** Remove leftover *.tmp-* files from previous crashes or interrupted writes. */
    private cleanStaleTemporaryFiles;
    /** Revision + scheduler without any task cloning; feeds the SSE event frame. */
    summary(): {
        revision: number;
        scheduler: TaskBoardSchedulerSnapshot;
    };
    state(): LedgerState;
    /**
     * Runtime-only projection for the 5 s Host poll. It copies just primitive
     * identifiers and timestamps, never the complete task/execution history or
     * an authoritative mutable object from the ledger.
     */
    runtimeView(): LedgerRuntimeView;
    /** Count armed, non-archived schedules without cloning task histories. */
    armedScheduleCount(): number;
    /**
     * The earliest armed `nextRunAt` strictly after the supplied Host time, or
     * undefined when no schedule is armed in the future. This is the instant the
     * Host arms its native timer at, so the board wakes exactly when work is due
     * instead of polling a fixed heartbeat.
     * @param now - current Host time in ms epoch.
     * @returns the nearest future trigger, or undefined when none is armed.
     */
    nextArmedRunAt(now: number): number | undefined;
    /** Return value-only references for schedules due at the supplied Host time. */
    dueSchedules(now: number): DueScheduleReference[];
    subscribe(listener: () => void): () => void;
    dispose(): void;
    applyRequest(requestId: string, action: TaskBoardAction, initiator?: string): {
        state: LedgerState;
        runs?: OpenedRun[];
    };
    /**
     * Open the cascade one due schedule triggers: an empty array means nothing
     * ran (already running, or a participant whose elevated permission is still
     * unconfirmed), and the rule rolls to its next occurrence either way.
     */
    openScheduled(taskId: string, nextRunAt: number | undefined, triggeredAt: number): OpenedRun[];
    skipMissed(now: number): void;
    setScheduler(patch: Partial<TaskBoardSchedulerSnapshot>): void;
    /**
     * Settle one execution. A cascade participant first records its OWN outcome
     * and only finalizes once every child execution in its run group has
     * settled, so a parent card leaves 'running' with the whole tree's verdict
     * rather than its own turn alone.
     */
    settle(taskId: string, executionId: string, outcome: ExecutionOutcome, error?: string): void;
    attachSession(taskId: string, executionId: string, sessionId: string): void;
    private apply;
    /**
     * The binding that makes a run illegal, if any.
     *
     * A plain cascade launches one session per participant, so every participant
     * carries its own resolved binding and each one gates the run. A team run
     * launches only the Lead session: the Lead's binding gates it, while a
     * subtask's OWN above-default pin cannot be applied to a teammate and is
     * refused instead of being silently dropped (an inherited binding is the
     * Lead's own and stays allowed once the Lead is confirmed).
     * @param root - the task being run.
     * @returns the first refusal, or undefined when the run may start.
     */
    private bindingRefusal;
    /**
     * The tasks a cascade from `rootId` would actually open executions for, with
     * their effective execution targets resolved. Archived members never run, and
     * a member that already has an open execution is skipped (a task cannot run
     * twice), so the result is the participant set the launch will use.
     */
    private cascadeParticipants;
    /** Whether a task or any of its subtasks still has an open execution. */
    private subtreeHasOpenExecution;
    /**
     * Open one execution per cascade participant (the requested task and its
     * on-board descendants, within the depth limit) under a single run group, and
     * commit the ledger once. The returned runs are ordered root-first, so the
     * Host launches the parent before its subtasks.
     * @param root - the task the user ran.
     * @param now - clock instant (ms epoch).
     * @param initiator - the DSH session that asked for the run (audit only).
     * @param rerun - true to reset the root to 'todo' before starting it.
     * @param nextRunAt - when set, the root's schedule also rolls forward.
     */
    private startCascade;
    /**
     * Finalize every cascade parent that is ready, walking from `taskId` up the
     * lineage: a member settles once its own outcome is recorded and none of its
     * group children is still open, and its verdict folds those children in
     * (failure dominates, then cancellation).
     */
    private settleCascade;
    /**
     * Close every run that is already decided, and fold every lineage whose
     * members are all settled. The Host poll calls this on every tick, so a run
     * can no longer be left in the running column by a settle nobody observed:
     *
     * - A team run is governed by its Lead. Once the Lead's own outcome is
     *   recorded, its still-open members are settled with that verdict. A
     *   teammate is a durable member of the Team and may never report a turn of
     *   its own, and without this the whole lineage waits on it forever.
     * - A cascade parent whose members are all settled is finalized here even
     *   when the settle that completed the tree happened in another process, or
     *   was interrupted between its child write and its parent write.
     *
     * Idempotent: a run that is already folded is left untouched, so a caller may
     * invoke it on every tick.
     * @param persist - false to leave the document for the caller to commit.
     * @returns whether the document changed.
     */
    finalizeReadyRuns(persist?: boolean): boolean;
    /**
     * The verdict a team run's Lead has already recorded: its own turn outcome
     * once that turn ended, or the folded outcome once its card settled.
     */
    private leadVerdict;
    /**
     * Settle every still-open member of a team run with the Lead's verdict.
     * A teammate that already reported its own outcome keeps it: the ordinary
     * fold still lets a failure dominate.
     * @param leadId - the Lead card's task id (never settled here).
     * @param groupId - the team run's group.
     * @param verdict - the Lead's outcome, inherited by members that never reported.
     * @param error - the Lead's failure text, inherited with a failed verdict.
     * @param now - clock instant (ms epoch).
     * @returns whether the document changed.
     */
    private closeTeamMembers;
    private repairSchedules;
    private reconcileInterruptedStarts;
    /**
     * Field-preserving migration of a pre-v4 document. It first proves every task
     * row is structurally valid, so a document that would silently drop or coerce
     * rows fails loudly instead (no quarantined-empty restart), and then reuses
     * the current normalization.
     *
     * v4 adds `ScheduleRule.timeZone`. A rule written before v4 was evaluated in
     * whatever zone the Host process happened to report, so the migration stamps
     * that zone onto every enabled rule: the trigger instant is preserved exactly
     * (the stored `nextRunAt` already encodes the old zone), but the rule stops
     * following a later `TZ` change, which is what made an existing schedule
     * silently move when the Host's zone changed.
     */
    private migrateLegacyDocument;
    private load;
    private normalizeDocument;
    /** Quarantine an unreadable document and start from an empty ledger. */
    private recoverCorrupt;
    private syncRecentRequests;
    private readSchedulerSidecar;
    /** Atomic write of the scheduler heartbeat sidecar (0600, tmp + rename + fsync). */
    private writeSchedulerSidecar;
    private commit;
    private notify;
    private acquireLock;
}
