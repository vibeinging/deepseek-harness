/**
 * Native panel registration for the task board.
 *
 * The board is an official-style center-column panel, not a DOM takeover: it
 * contributes a row into the sidebar shell's own global panel list
 * (`sidebar.panellist`) and its page into the layout's keyed `main` slot. The
 * shell then owns the row box, the label, the active highlight, the collapsed
 * rail, the panel switch and the window-chrome interplay exactly as it does for
 * the shipped Plugins and Schedule pages, so the board renders through the same
 * container the desktop application's Plugins page uses.
 *
 * Both registrations go through `ctx.slots.inject`, which fires only once the
 * owning shell entry has declared the seat: load order between this plugin and
 * ui-layout / ui-sidebar therefore does not matter, and neither does a shell
 * that cannot serve the seats (the callback simply never runs).
 *
 * @module @linxin666/dsh-client-ui-task-board/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { TASK_BOARD_PANEL_ID, type BoardController } from '../core/controller.ts';
/** The panel id shared by the sidebar row and the main-slot occupant. */
export { TASK_BOARD_PANEL_ID };
/**
 * The sidebar row glyph the shell asks for at its own size and active state.
 * The shell owns the button, label, tooltip and rail geometry; this component
 * draws only the glyph, like every other panel row.
 *
 * The glyph carries `data-dsh-panel-entry` because it is the only DOM the
 * panel's own code owns inside that shell-owned row: the L2 contract (skins)
 * resolves which row belongs to which plugin through it, since the shell
 * stamps no per-entry hook of its own (see contracts/semantic-attrs-v1.md).
 * @param props - the shell's icon share: square edge and selection state.
 * @returns the decorative board glyph.
 */
export declare function TaskBoardPanelIcon({ size }: {
    size: number;
    active: boolean;
}): React.ReactElement;
/**
 * The main-slot page. The layout mounts it only while the board is the selected
 * panel, so the conversation keeps the center column untouched the rest of the
 * time; the wrapper carries the pinned `data-dsh-taskboard-view` semantic
 * anchor (L2 contract, skins) and the container query context the board's
 * responsive rules read.
 * @param props - the framework main-slot share plus this entry's injected face.
 * @returns the board page.
 */
export declare function TaskBoardPanel({ controller }: {
    controller: BoardController;
}): React.ReactElement;
/**
 * Register the board's sidebar row and center-column page.
 *
 * Both seats are declared by shell plugins this package does not depend on at
 * runtime, so each registration is wrapped in `ctx.slots.inject`: the callback
 * runs only after the owning entry declares the seat, and a shell that never
 * declares it leaves the board simply absent instead of failing boot.
 * @param ctx - client root context (services: slots).
 * @param controller - the board controller the page and the row drive.
 * @returns disposer releasing both registrations.
 */
export declare function registerTaskBoardPanel(ctx: ClientContext, controller: BoardController): () => void;
