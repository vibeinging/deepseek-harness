import type { TaskRecord } from '../../core/tasks.ts';
/** Compact relative/absolute time label. */
export declare function formatHostTimestamp(ms: number, timeZone?: string): string;
export declare function formatTime(ms: number, timeZone?: string): string;
declare function TaskCardInner({ task, pending, timeZone, onClick, subtaskCount, isSubtask, subtasksDone, subtasksRunning, subtasksFailed, }: {
    task: TaskRecord;
    pending: boolean;
    timeZone?: string;
    onClick: () => void;
    /** Direct subtasks of this card, shown as a badge (0 hides it). */
    subtaskCount?: number;
    /** Whether this card is itself a subtask. */
    isSubtask?: boolean;
    /** Direct subtasks already settled as done, for the roll-up badge. */
    subtasksDone?: number;
    /** Direct subtasks currently running, for the roll-up badge. */
    subtasksRunning?: number;
    /** Direct subtasks that failed, for the roll-up badge. */
    subtasksFailed?: number;
}): import("react").JSX.Element;
/** Memoized card: re-renders only when the card's own task record changes. */
export declare const TaskCard: import("react").MemoExoticComponent<typeof TaskCardInner>;
export {};
