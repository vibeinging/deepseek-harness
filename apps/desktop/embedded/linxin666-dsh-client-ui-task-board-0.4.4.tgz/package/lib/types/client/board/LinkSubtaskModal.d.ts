import type { BoardController } from '../../core/controller.ts';
import type { TaskRecord } from '../../core/tasks.ts';
/** Link-subtask overlay props. */
export interface LinkSubtaskModalProps {
    controller: BoardController;
    /** The task the picked card becomes a subtask of. */
    parent: TaskRecord;
    onClose: () => void;
}
/** Link-subtask overlay. */
export declare function LinkSubtaskModal({ controller, parent, onClose }: LinkSubtaskModalProps): import("react").JSX.Element;
