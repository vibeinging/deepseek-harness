export declare function ClampedMarkdown({ source }: {
    source: string;
}): import("react").JSX.Element;
