/**
 * Family-shared tool-surface conventions for the packages that register
 * model-facing tools.
 *
 * One home for the prompt-section placement and the visibility gate this
 * family previously restated per package.
 *
 * Modelled on the official tool packages:
 * - `@deepseek-ai/dsh-tool-subagent` renders its section through
 *   `tools.get(name, context.scope) === undefined ? '' : text`, so guidance
 *   disappears together with a restricted tool.
 * - 21 of the 22 official tool packages register their tools GLOBALLY and gate
 *   them with a setting, not per agent. Only the Agent Teams tool package —
 *   whose tools belong to one membership — installs into each `agent.ctx`.
 *   This family follows the majority: registration stays global so the
 *   registry's per-scope `restrict()` mask (which filters inherited global
 *   tools and REJECTS scope-local names) can still withhold these tools.
 *
 * Structural types only: this copy lands in packages that do not all depend on
 * the same SDK service packages.
 */
/**
 * Prompt-section order for each package's tool guidance.
 *
 * These sit in the family band between the deployment persona and the SDK's
 * `PLAN_POLICY` (500). Values are owned here rather than written per package so
 * the host plugins whose guidance shares one prompt cannot drift into an
 * accidental tie.
 */
export declare const PLUGIN_TOOL_SECTION_ORDERS: {
    readonly ssh: 150;
    readonly 'task-board': 200;
};
/** One plugin id keyed by {@link PLUGIN_TOOL_SECTION_ORDERS}. */
export type PluginToolSectionId = keyof typeof PLUGIN_TOOL_SECTION_ORDERS;
/**
 * Order of an external provider extension's own guidance section, right after
 * the band of the plugin it extends.
 *
 * An extension names itself, not the plugin it plugs into, so its order stays
 * out of {@link PLUGIN_TOOL_SECTION_ORDERS}: every package's copy of this module
 * then carries no provider id. The slot still has one owner and cannot collide
 * with a host plugin's band.
 */
export declare const EXTENSION_TOOL_SECTION_ORDER = 210;
/**
 * The scoped tool lookup a section provider needs: the registry read for one
 * assembly's scope. Matches `ctx.tools.get(name, scope)`.
 */
export interface ScopedToolLookup {
    get(name: string, scope?: unknown): unknown;
}
/** One assembly context carrying the scope the section is rendered for. */
export interface SectionScopeContext {
    scope?: unknown;
}
/**
 * Build a section provider that renders \`text\` only while at least one of
 * \`toolNames\` is visible to the rendering scope.
 *
 * The native convention: a tool that a restriction, a preset, or a missing
 * registry removed must not leave guidance behind telling the model to call it.
 * An unreadable registry renders the text unchanged — guidance that outlives a
 * momentary read failure is recoverable; guidance for a tool that is gone is
 * not.
 * @param tools - the scoped tool registry, when the deployment serves one.
 * @param toolNames - registered names the guidance describes.
 * @param text - the guidance rendered while they are reachable.
 * @returns the section text provider.
 */
export declare function visibleToolText(tools: ScopedToolLookup | undefined, toolNames: readonly string[], text: string): (context: SectionScopeContext) => string;
