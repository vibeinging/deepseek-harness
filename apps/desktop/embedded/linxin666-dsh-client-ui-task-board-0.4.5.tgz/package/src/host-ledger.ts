import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { chmodSync, closeSync, existsSync, fsyncSync, mkdirSync, openSync, readdirSync, readFileSync, renameSync, statSync, unlinkSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { dshHome } from './dsh-home.ts'
import { isValidCron, isValidTimeZone, nextRunAtMs, resolveHostTimeZone } from './core/schedule.ts'
import { isTaskRecord, parseLedger } from './core/store.ts'
import { canMoveManually, hasOpenExecution, retainRecentExecutions, settleExecution, startExecution, withStatus, type ExecutionOutcome, type ExecutionRecord, type TaskRecord } from './core/tasks.ts'
import {
  DEFAULT_SUBTASK_DEPTH,
  cascadeTargets,
  combineCascadeOutcome,
  normalizeSubtaskDepth,
  openGroupExecution,
  pendingCascadeChildren,
  resolveExecutionTargets,
} from './core/subtask.ts'
import { applyArchiveTask, applyRestoreTask } from './core/use-cases/task-archive.ts'
import { applyCreateTask } from './core/use-cases/task-create.ts'
import { applyDeleteTask } from './core/use-cases/task-delete.ts'
import { applySetSchedule, applyScheduleNextRun } from './core/use-cases/task-schedule.ts'
import { applySetParent } from './core/use-cases/task-parent.ts'
import { applyDeleteTag, applyRenameTag } from './core/use-cases/task-tag.ts'
import { applyUpdateTask, canEditTaskContent, hasContentPatch } from './core/use-cases/task-update.ts'
import { TASK_BOARD_MIGRATABLE_SCHEMA_VERSIONS, TASK_BOARD_SCHEMA_VERSION, type TaskBoardAction, type TaskBoardSchedulerSnapshot } from './protocol.ts'
import type { ExecutionVerification } from './core/verification.ts'
import { DEFAULT_SESSION_PERMISSION, effectivePermission, permissionCarriedBy, requiresPermissionConfirmation, type TaskPermission } from './core/handover.ts'

interface PersistedScheduler extends TaskBoardSchedulerSnapshot {
  importedSources?: string[]
}

interface PersistedRequest {
  requestId: string
  fingerprint: string
}

/** On-disk document of any schema generation (schemaVersion untyped until the load branches decide). */
type ParsedLedgerDocument = Omit<Partial<LedgerDocument>, 'schemaVersion'> & { schemaVersion?: unknown }

interface LedgerDocument {
  schemaVersion: typeof TASK_BOARD_SCHEMA_VERSION
  revision: number
  tasks: TaskRecord[]
  scheduler: PersistedScheduler
  recentRequests: PersistedRequest[]
}

export interface LedgerState {
  revision: number
  tasks: TaskRecord[]
  scheduler: TaskBoardSchedulerSnapshot
}

/** Human-facing text for a refused binding, per surface. */
function bindingRefusalMessage(
  refusal: { kind: 'root' | 'inherited' | 'subtask-pin'; title: string },
  sessionDefault: TaskPermission,
  surface: 'run' | 'schedule',
): string {
  if (refusal.kind === 'subtask-pin') {
    return `team run cannot honor the permission binding of subtask "${refusal.title}": a teammate runs inside the Lead session and inherits its permission, which that pin exceeds; clear the card's permission or run the tree without Agent Team`
  }
  if (surface === 'schedule') return `task "${refusal.title}" has an unconfirmed above-default permission`
  if (refusal.kind === 'root') {
    return `confirmation-required: the effective permission is above the session default (${sessionDefault}); confirm the card's permission binding first`
  }
  return `confirmation-required: subtask "${refusal.title}" inherits an above-default permission; confirm that card's permission binding first`
}

export interface OpenedRun {
  task: TaskRecord
  execution: ExecutionRecord
  /**
   * How the Host obtains this run's session. Absent or `session` launches a
   * fresh (or reused) execution session; `teammate` means the run belongs to a
   * team-mode cascade, where the Host asks the root's Lead session to spawn a
   * teammate instead of launching a session of its own.
   */
  dispatch?: 'session' | 'teammate'
}

/** Minimal value copy used by the Host session monitor. */
export interface OpenExecutionReference {
  readonly taskId: string
  readonly executionId: string
  readonly sessionId: string | undefined
  readonly startedAt: number
  /**
   * True for a member of a team-mode run other than its Lead. A teammate is a
   * durable member of the Team: it stays alive after its turn ends, so the
   * roster may keep reporting its session as running, and the turn it completed
   * is the only verdict it exposes.
   */
  readonly teamMember: boolean
}

/** Minimal value copy used by the Host scheduler. */
export interface DueScheduleReference {
  readonly taskId: string
  readonly cron: string
  /** Zone this rule's wall clock is read in. */
  readonly timeZone: string
  readonly nextRunAt: number
}

/** Derived runtime data for one session-poll pass. */
export interface LedgerRuntimeView {
  readonly armedSchedules: number
  readonly openExecutions: readonly OpenExecutionReference[]
}

const MAX_REQUEST_CACHE = 256

interface CachedRequest {
  fingerprint: string
}

function timeZone(): string {
  return resolveHostTimeZone()
}

/** The zone a schedule is evaluated in: its own, or the Host zone when it stores none. */
function scheduleZone(schedule: { timeZone?: string }): string {
  return schedule.timeZone ?? timeZone()
}

function cloneTasks(tasks: readonly TaskRecord[]): TaskRecord[] {
  return JSON.parse(JSON.stringify(tasks)) as TaskRecord[]
}

/**
 * Process states that are dead but still occupy the PID table: `Z` (zombie)
 * and `X` (dead, being reaped). `process.kill(pid, 0)` reports such PIDs as
 * alive, so a crash leftover whose child was never reaped would otherwise be
 * mistaken for a live owner and block ledger startup forever.
 */
const DEAD_STATES = new Set(['Z', 'X'])

/**
 * Best-effort single-letter process state ('R','S','D','Z',...) or undefined
 * when no probe is available on this platform. Linux reads /proc/<pid>/stat
 * directly (no subprocess); other POSIX shells out to `ps -o stat=`; Windows
 * has no zombie state, so it returns undefined and the kill(0) probe alone
 * is authoritative there.
 */
export function processState(pid: number): string | undefined {
  if (process.platform === 'linux') {
    try {
      const stat = readFileSync(`/proc/${pid}/stat`, 'utf8')
      const end = stat.lastIndexOf(')')
      if (end === -1) return undefined
      return stat.slice(end + 2).split(' ')[0] || undefined
    } catch {
      return undefined // no such process (or unreadable)
    }
  }
  if (process.platform === 'win32') return undefined
  try {
    const probe = spawnSync('ps', ['-o', 'stat=', '-p', String(pid)], { timeout: PROCESS_PROBE_TIMEOUT_MS })
    if (probe.status !== 0 || probe.stdout.length === 0) return undefined
    const state = probe.stdout.toString('utf8').trim()
    return state.length > 0 ? state[0] : undefined
  } catch {
    return undefined
  }
}

export function processIsAlive(pid: number): boolean {
  if (!Number.isSafeInteger(pid) || pid <= 0) return false
  const state = processState(pid)
  if (state !== undefined && DEAD_STATES.has(state)) return false
  try {
    process.kill(pid, 0)
    return true
  } catch (error) {
    return (error as NodeJS.ErrnoException).code !== 'ESRCH'
  }
}

const PROCESS_PROBE_TIMEOUT_MS = 3000
/**
 * The CIM fallback pays a WMI cold start, so it gets a wider budget than the
 * direct `Get-Process` read it backs up.
 */
const CIM_PROBE_TIMEOUT_MS = 8000

let ownStartTime: number | undefined
let ownStartTimeResolved = false

/**
 * Exact process start time (Unix epoch ms) on Linux, read straight from
 * /proc (field 22 = start ticks since boot, btime = boot epoch seconds).
 * No subprocess and no rounding, so the recorded `startedAt` from a previous
 * boot compares exactly against the live process identity.
 */
function linuxStartTimeMs(pid: number): number | undefined {
  try {
    const stat = readFileSync(`/proc/${pid}/stat`, 'utf8')
    const end = stat.lastIndexOf(')')
    if (end === -1) return undefined
    const ticks = Number(stat.slice(end + 2).split(' ')[19])
    if (!Number.isFinite(ticks)) return undefined
    const bootMatch = /^btime\s+(\d+)/m.exec(readFileSync('/proc/stat', 'utf8'))
    if (bootMatch === null) return undefined
    const btime = Number(bootMatch[1])
    if (!Number.isFinite(btime)) return undefined
    return btime * 1000 + (ticks * 1000) / 100 // USER_HZ is 100 on Linux
  } catch {
    return undefined
  }
}

/** Runs one PowerShell script and returns its trimmed stdout. */
export type PowerShellProbe = (script: string, timeoutMs: number) => string | undefined

/** Default probe: one hidden, profile-free PowerShell process per script. */
const runPowerShellProbe: PowerShellProbe = (script, timeoutMs) => {
  const probe = spawnSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', script], {
    timeout: timeoutMs,
    windowsHide: true,
  })
  if (probe.status !== 0 || probe.stdout.length === 0) return undefined
  return probe.stdout.toString('utf8').trim()
}

/** The epoch-millisecond reading a probe printed, or undefined when unusable. */
function parseProbeEpochMs(raw: string | undefined): number | undefined {
  if (raw === undefined || raw.trim() === '') return undefined
  const started = Number(raw.trim())
  return Number.isFinite(started) ? started : undefined
}

/** Start time through Get-Process: precise, but empty for protected processes. */
function getProcessStartScript(pid: number): string {
  return '[DateTimeOffset]::FromFileTime((Get-Process -Id ' + String(pid)
    + ' -ErrorAction SilentlyContinue).StartTime.ToUniversalTime().ToFileTime()).ToUnixTimeMilliseconds()'
}

/** Start time through Win32_Process: readable for System/svchost too. */
function cimStartScript(pid: number): string {
  return '$p=Get-CimInstance Win32_Process -Filter "ProcessId=' + String(pid)
    + '" -ErrorAction SilentlyContinue;if($p -ne $null){[DateTimeOffset]::FromFileTime($p.CreationDate.ToUniversalTime().ToFileTime()).ToUnixTimeMilliseconds()}'
}

/**
 * Windows start time (Unix epoch ms) of a live process.
 *
 * `Get-Process` is the precise first choice, but an unprivileged caller cannot
 * read `.StartTime` for a protected process (System, svchost): the property is
 * empty, so the probe returns nothing. Without a fallback, a crash leftover
 * lock whose PID was reused by such a process could never be proven stale and
 * blocked every startup until the lock was deleted by hand (issue #1629).
 * Win32_Process through CIM reports the same CreationDate for those processes
 * at the same millisecond precision, so it is the second identity source. The
 * probe is injectable so the fallback chain is testable off Windows.
 */
export function win32StartTimeMs(pid: number, probe: PowerShellProbe = runPowerShellProbe): number | undefined {
  // The pid is interpolated into a PowerShell script, so it must be a plain
  // positive integer before any probe runs.
  if (!Number.isSafeInteger(pid) || pid <= 0) return undefined
  const direct = parseProbeEpochMs(probe(getProcessStartScript(pid), PROCESS_PROBE_TIMEOUT_MS))
  if (direct !== undefined) return direct
  return parseProbeEpochMs(probe(cimStartScript(pid), CIM_PROBE_TIMEOUT_MS))
}

/**
 * Best-effort start time (Unix epoch ms) of a live process. Used to prove
 * whether the ledger lock really belongs to the PID recorded in it, so a
 * crash leftover whose PID was reused by an unrelated process (issue #786)
 * is detected as stale instead of blocking startup forever. Returns
 * undefined when the platform probe is unavailable; callers fail closed.
 */
function processStartTimeMs(pid: number): number | undefined {
  if (process.platform === 'linux') return linuxStartTimeMs(pid)
  if (process.platform === 'win32') return win32StartTimeMs(pid)
  // Other POSIX (macOS...): ps lstart with a forced English locale, falling
  // back to the elapsed-seconds column when lstart cannot be parsed.
  const env = { ...process.env, LC_ALL: 'C' }
  const probe = spawnSync('ps', ['-o', 'lstart=', '-p', String(pid)], { timeout: PROCESS_PROBE_TIMEOUT_MS, env })
  if (probe.status === 0 && probe.stdout.length > 0) {
    const started = Date.parse(probe.stdout.toString('utf8').trim())
    if (Number.isFinite(started)) return started
  }
  const elapsed = spawnSync('ps', ['-o', 'etimes=', '-p', String(pid)], { timeout: PROCESS_PROBE_TIMEOUT_MS, env })
  if (elapsed.status !== 0 || elapsed.stdout.length === 0) return undefined
  const seconds = Number(elapsed.stdout.toString('utf8').trim())
  if (!Number.isFinite(seconds)) return undefined
  return Date.now() - seconds * 1000
}

function ownProcessStartTimeMs(): number | undefined {
  if (!ownStartTimeResolved) {
    ownStartTimeResolved = true
    ownStartTime = processStartTimeMs(process.pid)
  }
  return ownStartTime
}

/**
 * Bounded tolerance for legacy lock records. Locks written before the
 * ms-precise probe recorded `startedAt` from `ps -o lstart=` at whole-second
 * resolution; probing the SAME live process exactly (via /proc) then differs
 * in the sub-second remainder. Treating that as PID reuse would steal a live
 * owner's lock during a rolling upgrade and start a second ledger writer.
 * Records written by the ms-precise probe carry `probe: 'exact'` and are
 * compared strictly; anything else (older locks, second-granularity probes)
 * falls back to this bounded tolerance.
 */
const LEGACY_START_TOLERANCE_MS = 2000

/**
 * How long an unreadable lock must sit untouched before it may be reclaimed.
 * The owner writes and fsyncs its record immediately after creating the file
 * with O_EXCL, so a lock that cannot be parsed may still be mid-write by a
 * live owner; only one that has been unreadable for longer than any write can
 * take is treated as an unclean-shutdown leftover (issue #1528: a 0-byte lock
 * kept the Host half from mounting until it was deleted by hand).
 */
const UNREADABLE_LOCK_GRACE_MS = 60_000

/** Whether the recorded start time proves the recorded PID is another process. */
function startTimeMismatch(recorded: number, actual: number, exact: boolean): boolean {
  return exact ? recorded !== actual : Math.abs(recorded - actual) > LEGACY_START_TOLERANCE_MS
}

function betterExecution(a: ExecutionRecord, b: ExecutionRecord): ExecutionRecord {
  if (a.endedAt === undefined && b.endedAt !== undefined) return b
  if (b.endedAt === undefined && a.endedAt !== undefined) return a
  return (b.endedAt ?? b.startedAt) >= (a.endedAt ?? a.startedAt) ? b : a
}

function mergeTask(a: TaskRecord, b: TaskRecord): TaskRecord {
  // Existing Host state wins ties so an equally old browser backup cannot
  // roll authoritative fields back during multi-browser v1 migration.
  const newer = b.updatedAt > a.updatedAt ? b : a
  const byId = new Map<string, ExecutionRecord>()
  for (const entry of [...a.executions, ...b.executions]) {
    const previous = byId.get(entry.id)
    byId.set(entry.id, previous === undefined ? entry : betterExecution(previous, entry))
  }
  // Acceptance evidence is the one field "betterExecution" cannot choose: a
  // browser half that also wrote this execution carries no attempts, and taking
  // its copy would erase the Host's verdict. The copy with the most recorded
  // attempts wins, and one execution's verdict is never copied onto another.
  const executions = [...byId.values()].sort((x, y) => x.startedAt - y.startedAt).map(entry => {
    if (entry.verification !== undefined) return entry
    const richer = [...a.executions, ...b.executions]
      .filter(other => other.id === entry.id && other.verification !== undefined)
      .sort((x, y) => (y.verification?.attempts.length ?? 0) - (x.verification?.attempts.length ?? 0))[0]
    return richer?.verification === undefined ? entry : { ...entry, verification: richer.verification }
  })
  return { ...newer, executions: retainRecentExecutions(executions) }
}

/**
 * Repair parent links after a load or an import: a link whose parent row is
 * missing, cyclic, or names an archived parent while the child is on board is
 * dropped (the task becomes a root) instead of dropping the task. A chain
 * deeper than the current `maxSubtaskDepth` is deliberately KEPT: the limit
 * gates new links, it never deletes a stored one, and every cascade walk is
 * bounded by the limit anyway. The Host is the only writer of these links, so
 * this is a last-resort guard against a hand-edited or imported document.
 */
export function repairParentLinks(tasks: readonly TaskRecord[]): TaskRecord[] {
  const byId = new Map(tasks.map(task => [task.id, task]))
  return tasks.map(task => {
    if (task.parentId === undefined) return task
    const seen = new Set<string>([task.id])
    let current: TaskRecord | undefined = byId.get(task.parentId)
    let depth = 0
    while (current !== undefined) {
      // The first hop is the parent itself: an archived parent holding an
      // on-board child is outside the archive cascade invariant, and only an
      // import can produce it.
      if (seen.has(current.id) || (depth === 0 && current.archivedAt !== undefined && task.archivedAt === undefined)) {
        return { ...task, parentId: undefined }
      }
      seen.add(current.id)
      depth += 1
      current = current.parentId === undefined ? undefined : byId.get(current.parentId)
    }
    // A walk that never started (depth 0) means the parent row did not survive
    // the parse: the link is dangling and the task goes back to the root.
    return depth === 0 ? { ...task, parentId: undefined } : task
  })
}

function parseHostTasks(values: readonly unknown[]): TaskRecord[] {
  const rawById = new Map<string, Record<string, unknown>>()
  for (const value of values) {
    if (typeof value !== 'object' || value === null) continue
    const raw = value as Record<string, unknown>
    if (typeof raw.id === 'string') rawById.set(raw.id, raw)
  }
  return repairParentLinks(parseLedger(JSON.stringify(values))).map(task => {
    const rawSchedule = rawById.get(task.id)?.schedule
    if (typeof rawSchedule !== 'object' || rawSchedule === null) return task
    const schedule = rawSchedule as Record<string, unknown>
    if (typeof schedule.cron !== 'string' || isValidCron(schedule.cron)) return task
    return {
      ...task,
      schedule: {
        enabled: false,
        cron: schedule.cron,
        ...(typeof schedule.timeZone === 'string' && isValidTimeZone(schedule.timeZone) ? { timeZone: schedule.timeZone } : {}),
        nextRunAt: undefined,
        lastTriggeredAt: typeof schedule.lastTriggeredAt === 'number' && Number.isFinite(schedule.lastTriggeredAt)
          ? schedule.lastTriggeredAt
          : undefined,
      },
    }
  })
}

export class HostTaskLedger {
  private document: LedgerDocument
  private readonly listeners = new Set<() => void>()
  private readonly requestCache = new Map<string, CachedRequest>()
  private readonly lockToken = crypto.randomUUID()
  private lockFd: number | undefined
  readonly file: string
  readonly lockFile: string
  /** Small sidecar for the 30 s scheduler heartbeat (lastTickAt only). */
  readonly schedulerFile: string

  /** Resolves the baseline the confirmation gate compares a binding against. */
  private readonly sessionDefault: () => TaskPermission

  /**
   * Session-default permission the confirmation gate compares against. Read
   * through the resolver on every use, so a baseline that follows the Host's
   * own default preset tracks a Settings change made while the board runs.
   */
  get sessionDefaultPermission(): TaskPermission {
    return this.sessionDefault()
  }

  /**
   * Deployment subtask depth limit (1..3): the lineage gate every write obeys.
   * The settings card edits it live, so {@link setMaxSubtaskDepth} mutates it
   * instead of remounting the row.
   */
  private depthLimit: number

  constructor(dir: string = join(dshHome(), 'task-board'), private readonly now: () => number = Date.now, options: { sessionDefaultPermission?: TaskPermission | (() => TaskPermission); maxSubtaskDepth?: number } = {}) {
    // Resolved before the load/repair passes below: they can evaluate the gate.
    const baseline = options.sessionDefaultPermission
    this.sessionDefault = typeof baseline === 'function' ? baseline : () => baseline ?? DEFAULT_SESSION_PERMISSION
    this.depthLimit = normalizeSubtaskDepth(options.maxSubtaskDepth ?? DEFAULT_SUBTASK_DEPTH)
    mkdirSync(dir, { recursive: true })
    this.file = join(dir, 'ledger-v2.json')
    this.lockFile = join(dir, 'ledger-v2.lock')
    this.schedulerFile = join(dir, 'scheduler-v2.json')
    this.cleanStaleTemporaryFiles(dir)
    this.lockFd = this.acquireLock()
    try {
      this.document = this.load(dir)
      for (const request of this.document.recentRequests) {
        this.requestCache.set(request.requestId, { fingerprint: request.fingerprint })
      }
      this.repairSchedules(true)
      this.reconcileInterruptedStarts()
      // Boot recovery also folds every already-decided run: a team run whose
      // Lead recorded its verdict in an earlier process, and a lineage whose
      // last settle never reached its parent, both leave the running column here.
      this.finalizeReadyRuns(false)
      // Persist a freshly generated ledger identity and any recovery error
      // immediately, even when there are no tasks to trigger a later action.
      this.commit(false)
    } catch (error) {
      this.dispose()
      throw error
    }
  }

  /** Current subtask depth limit (1..3). */
  get maxSubtaskDepth(): number {
    return this.depthLimit
  }

  /**
   * Apply a live settings edit of the subtask depth limit. A no-op when the
   * normalized limit is unchanged, so a coarse volatile invalidation that
   * changed nothing emits nothing.
   */
  setMaxSubtaskDepth(depth: number): void {
    const next = normalizeSubtaskDepth(depth)
    if (next === this.depthLimit) return
    this.depthLimit = next
    this.notify()
  }

  /** Remove leftover *.tmp-* files from previous crashes or interrupted writes. */
  private cleanStaleTemporaryFiles(dir: string): void {
    try {
      const entries = readdirSync(dir)
      for (const entry of entries) {
        if (entry.includes('.tmp-')) {
          try {
            unlinkSync(join(dir, entry))
          } catch {
            // Best-effort cleanup
          }
        }
      }
    } catch {
      // Directory may not exist yet or cannot be read
    }
  }

  /** Revision + scheduler without any task cloning; feeds the SSE event frame. */
  summary(): { revision: number; scheduler: TaskBoardSchedulerSnapshot } {
    const { importedSources: _imports, ...scheduler } = this.document.scheduler
    return { revision: this.document.revision, scheduler: { ...scheduler } }
  }

  state(): LedgerState {
    const { revision, scheduler } = this.summary()
    return { revision, tasks: cloneTasks(this.document.tasks), scheduler }
  }

  /**
   * Runtime-only projection for the 5 s Host poll. It copies just primitive
   * identifiers and timestamps, never the complete task/execution history or
   * an authoritative mutable object from the ledger.
   */
  runtimeView(): LedgerRuntimeView {
    let armedSchedules = 0
    // Run groups opened by a team-mode card: every other member of those groups
    // runs as a teammate inside that card's Lead session.
    const teamGroups = new Set<string>()
    for (const task of this.document.tasks) {
      if (task.teamRun !== true) continue
      for (const execution of task.executions) {
        if (execution.runGroupId !== undefined) teamGroups.add(execution.runGroupId)
      }
    }
    const openExecutions: OpenExecutionReference[] = []
    for (const task of this.document.tasks) {
      if (task.archivedAt === undefined && task.schedule?.enabled === true) armedSchedules += 1
      for (const execution of task.executions) {
        if (execution.endedAt !== undefined) continue
        // A deferred cascade parent already knows its own outcome; the monitor
        // has nothing left to inspect, and its children's settles finalize it.
        if (execution.ownResult !== undefined) continue
        openExecutions.push({
          taskId: task.id,
          executionId: execution.id,
          sessionId: execution.sessionId,
          startedAt: execution.startedAt,
          teamMember: task.teamRun !== true
            && execution.runGroupId !== undefined
            && teamGroups.has(execution.runGroupId),
        })
      }
    }
    return { armedSchedules, openExecutions }
  }

  /** Count armed, non-archived schedules without cloning task histories. */
  armedScheduleCount(): number {
    let count = 0
    for (const task of this.document.tasks) {
      if (task.archivedAt === undefined && task.schedule?.enabled === true) count += 1
    }
    return count
  }

  /**
   * The earliest armed `nextRunAt` strictly after the supplied Host time, or
   * undefined when no schedule is armed in the future. This is the instant the
   * Host arms its native timer at, so the board wakes exactly when work is due
   * instead of polling a fixed heartbeat.
   * @param now - current Host time in ms epoch.
   * @returns the nearest future trigger, or undefined when none is armed.
   */
  nextArmedRunAt(now: number): number | undefined {
    let nearest: number | undefined
    for (const task of this.document.tasks) {
      if (task.archivedAt !== undefined) continue
      const schedule = task.schedule
      if (schedule === undefined || !schedule.enabled || schedule.nextRunAt === undefined) continue
      if (schedule.nextRunAt <= now) continue
      if (nearest === undefined || schedule.nextRunAt < nearest) nearest = schedule.nextRunAt
    }
    return nearest
  }

  /** Return value-only references for schedules due at the supplied Host time. */
  dueSchedules(now: number): DueScheduleReference[] {
    const due: DueScheduleReference[] = []
    for (const task of this.document.tasks) {
      if (task.archivedAt !== undefined) continue
      const schedule = task.schedule
      if (schedule === undefined || !schedule.enabled || schedule.nextRunAt === undefined || schedule.nextRunAt > now) continue
      due.push({ taskId: task.id, cron: schedule.cron, timeZone: scheduleZone(schedule), nextRunAt: schedule.nextRunAt })
    }
    return due
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  dispose(): void {
    const fd = this.lockFd
    if (fd === undefined) return
    this.lockFd = undefined
    closeSync(fd)
    try {
      const owner = JSON.parse(readFileSync(this.lockFile, 'utf8')) as { token?: unknown }
      if (owner.token === this.lockToken) unlinkSync(this.lockFile)
    } catch {
      // A missing or externally replaced lock must not be removed blindly.
    }
  }

  applyRequest(
    requestId: string,
    action: TaskBoardAction,
    initiator?: string,
  ): { state: LedgerState; runs?: OpenedRun[] } {
    const fingerprint = createHash('sha256').update(JSON.stringify(action)).digest('hex')
    const cached = this.requestCache.get(requestId)
    if (cached !== undefined) {
      if (cached.fingerprint !== fingerprint) throw new Error('request id was reused with a different action')
      return { state: this.state() }
    }

    // Add the fingerprint before apply(): successful actions persist it in the
    // same atomic ledger write as their state transition.
    this.requestCache.set(requestId, { fingerprint })
    while (this.requestCache.size > MAX_REQUEST_CACHE) this.requestCache.delete(this.requestCache.keys().next().value as string)
    this.syncRecentRequests()
    try {
      return this.apply(action, initiator)
    } catch (error) {
      this.requestCache.delete(requestId)
      this.syncRecentRequests()
      throw error
    }
  }

  /**
   * Open the cascade one due schedule triggers: an empty array means nothing
   * ran (already running, or a participant whose elevated permission is still
   * unconfirmed), and the rule rolls to its next occurrence either way.
   */
  openScheduled(taskId: string, nextRunAt: number | undefined, triggeredAt: number): OpenedRun[] {
    const task = this.document.tasks.find(item => item.id === taskId)
    if (task === undefined || task.archivedAt !== undefined) return []
    const rollForward = (): void => {
      this.document.tasks = [...applyScheduleNextRun(this.document.tasks, taskId, nextRunAt, task.schedule?.lastTriggeredAt, triggeredAt)]
      this.commit()
    }
    const refusal = this.bindingRefusal(task)
    if (refusal !== undefined) {
      // An unconfirmed above-default permission must never run unattended: the
      // whole tree is refused and the schedule rolls to the next occurrence,
      // exactly like the already-running refusal.
      this.document.scheduler.error = `scheduled run refused for task ${taskId}: ${bindingRefusalMessage(refusal, this.sessionDefaultPermission, 'schedule')}`
      rollForward()
      return []
    }
    if (hasOpenExecution(task)) {
      rollForward()
      return []
    }
    return this.startCascade(task, triggeredAt, undefined, false, nextRunAt)
  }

  skipMissed(now: number): void {
    let changed = false
    this.document.tasks = this.document.tasks.map(task => {
      const schedule = task.schedule
      if (schedule === undefined || !schedule.enabled || schedule.nextRunAt === undefined || schedule.nextRunAt > now) return task
      changed = true
      return { ...task, schedule: { ...schedule, nextRunAt: nextRunAtMs(schedule.cron, now, scheduleZone(schedule)) }, updatedAt: now }
    })
    if (changed) this.commit()
  }

  setScheduler(patch: Partial<TaskBoardSchedulerSnapshot>): void {
    this.document.scheduler = { ...this.document.scheduler, ...patch }
    // The 30 s heartbeat only moves lastTickAt; rewriting the whole ledger
    // for it made idle idle cost O(ledger bytes) every tick. Persist it to a
    // tiny sidecar instead; any other patch still goes through the full
    // atomic commit.
    if (patch.lastTickAt !== undefined && Object.keys(patch).every(key => key === 'lastTickAt')) {
      try {
        this.writeSchedulerSidecar()
      } catch (error) {
        if ((error as NodeJS.ErrnoException)?.code === 'ENOSPC') {
          // Disk is full; sidecar persistence fails, but in-memory heartbeat
          // remains updated. Swallow to prevent unhandled log cascade crashes.
          return
        }
        throw error
      }
      return
    }
    this.commit(false)
  }

  /**
   * Settle one execution. A cascade participant first records its OWN outcome
   * and only finalizes once every child execution in its run group has
   * settled, so a parent card leaves 'running' with the whole tree's verdict
   * rather than its own turn alone.
   */
  settle(taskId: string, executionId: string, outcome: ExecutionOutcome, error?: string): void {
    const now = this.now()
    const task = this.document.tasks.find(item => item.id === taskId)
    const execution = task?.executions.find(entry => entry.id === executionId)
    if (task === undefined || execution === undefined || execution.endedAt !== undefined) return
    const groupId = execution.runGroupId
    if (groupId === undefined) {
      this.document.tasks = this.document.tasks.map(item => item.id === taskId
        ? settleExecution(item, executionId, outcome, now, error)
        : item)
      this.commit()
      return
    }
    let changed = false
    if (execution.ownResult === undefined) {
      this.document.tasks = this.document.tasks.map(item => item.id !== taskId ? item : {
        ...item,
        updatedAt: now,
        executions: item.executions.map(entry => entry.id === executionId ? { ...entry, ownResult: outcome, ownError: error } : entry),
      })
      changed = true
    }
    // A team run is governed by its Lead: the Lead's own outcome closes whatever
    // the Team still holds open, so the tree can never wait on a teammate that
    // will never report one.
    if (task.teamRun === true
      && this.closeTeamMembers(taskId, groupId, execution.ownResult ?? outcome, execution.ownError ?? error, now)) changed = true
    if (this.settleCascade(taskId, groupId, now)) changed = true
    if (changed) this.commit()
  }

  attachSession(taskId: string, executionId: string, sessionId: string): void {
    const now = this.now()
    const task = this.document.tasks.find(item => item.id === taskId)
    // A run the Lead's verdict already closed keeps its record: attaching a
    // session to a settled execution would rewrite history the Host no longer
    // observes (a teammate spawn that resolved after its Team was closed).
    if (task?.executions.find(entry => entry.id === executionId)?.endedAt !== undefined) return
    this.document.tasks = this.document.tasks.map(item => item.id !== taskId ? item : {
      ...item,
      updatedAt: now,
      executions: item.executions.map(entry => entry.id === executionId ? { ...entry, sessionId } : entry),
    })
    this.commit()
  }

  allTasks(): readonly TaskRecord[] {
    return this.document.tasks
  }

  getTask(id: string): TaskRecord | undefined {
    return this.document.tasks.find(item => item.id === id)
  }

  saveTaskRecord(task: TaskRecord): void {
    const exists = this.document.tasks.some(item => item.id === task.id)
    if (exists) {
      this.document.tasks = this.document.tasks.map(item => item.id === task.id ? task : item)
    } else {
      this.document.tasks = [...this.document.tasks, task]
    }
    this.commit()
  }

  private apply(action: TaskBoardAction, initiator?: string): { state: LedgerState; runs?: OpenedRun[] } {
    const now = this.now()
    let runs: OpenedRun[] | undefined
    switch (action.kind) {
      case 'import': {
        const sources = new Set(this.document.scheduler.importedSources ?? [])
        if (sources.has(action.sourceId)) return { state: this.state() }
        const invalidScheduleIds = action.tasks
          .filter(task => task.schedule !== undefined && !isValidCron(task.schedule.cron))
          .map(task => task.id)
        const incoming = parseHostTasks(action.tasks)
        const merged = new Map(this.document.tasks.map(task => [task.id, task]))
        for (const task of incoming) merged.set(task.id, merged.has(task.id) ? mergeTask(merged.get(task.id)!, task) : task)
        // An imported child can name a parent this ledger has never seen (a
        // partial export): the dangling link is dropped, the task survives.
        this.document.tasks = repairParentLinks([...merged.values()])
        this.document.scheduler.importedSources = [...sources, action.sourceId]
        this.document.scheduler.error = invalidScheduleIds.length === 0
          ? undefined
          : `invalid cron disabled for task(s): ${invalidScheduleIds.join(', ')}`
        this.repairSchedules(true, false)
        this.reconcileInterruptedStarts(false)
        // An imported document may carry a decided-but-open run; fold it in the
        // same action (apply() commits once at the end).
        this.finalizeReadyRuns(false)
        break
      }
      case 'create': {
        if (this.document.tasks.some(task => task.id === action.id)) throw new Error('task id already exists')
        if (action.input.schedule?.enabled === true && (!isValidCron(action.input.schedule.cron)
          || !isValidTimeZone(action.input.schedule.timeZone ?? timeZone())
          || nextRunAtMs(action.input.schedule.cron, now, action.input.schedule.timeZone ?? timeZone()) === undefined)) {
          throw new Error('invalid schedule')
        }
        const input = action.input.freeze === undefined || initiator === undefined || initiator === ''
          ? action.input
          : { ...action.input, freeze: { ...action.input.freeze, frozenBy: initiator } }
        const result = applyCreateTask(this.document.tasks, input, now, action.id, this.maxSubtaskDepth, timeZone())
        if (result.task === undefined) throw new Error(result.error ?? 'invalid task')
        this.document.tasks = [...result.tasks]
        break
      }
      case 'update': {
        const task = this.document.tasks.find(task => task.id === action.taskId)
        if (task === undefined) throw new Error('task not found')
        if (task.archivedAt !== undefined) throw new Error('archived task is read-only')
        // The task content (title/description/prompt) is the record of what
        // was planned; once an execution started it must not change under a
        // running session or an executed history. Execution targets stay
        // editable (they only affect future runs).
        if (hasContentPatch(action.patch) && !canEditTaskContent(task)) {
          throw new Error('task has already been executed')
        }
        if ('title' in action.patch && action.patch.title?.trim() === '') throw new Error('title is required')
        // A replaced snapshot is re-stamped with the updating session (the
        // initiator), so a swapped freeze cannot keep the old author stamp.
        const patch = action.patch.freeze === null || action.patch.freeze === undefined || initiator === undefined || initiator === ''
          ? action.patch
          : { ...action.patch, freeze: { ...action.patch.freeze, frozenBy: initiator } }
        this.document.tasks = [...applyUpdateTask(this.document.tasks, action.taskId, patch, now)]
        break
      }
      case 'delete': {
        const task = this.document.tasks.find(task => task.id === action.taskId)
        if (task === undefined) throw new Error('task not found')
        if (hasOpenExecution(task)) throw new Error('running task cannot be deleted')
        // Subtasks keep their link: deleting the parent would leave dangling
        // children, so the user detaches or deletes them explicitly first.
        if (this.document.tasks.some(item => item.parentId === action.taskId)) {
          throw new Error('task has subtasks; detach or delete them first')
        }
        this.document.tasks = [...applyDeleteTask(this.document.tasks, undefined, action.taskId).tasks]
        break
      }
      case 'set-parent': {
        const result = applySetParent(this.document.tasks, action.taskId, action.parentId, now, this.maxSubtaskDepth)
        if (!result.applied) throw new Error(result.error ?? 'parent link refused')
        this.document.tasks = [...result.tasks]
        break
      }
      case 'move': {
        const task = this.document.tasks.find(item => item.id === action.taskId)
        if (task === undefined) throw new Error('task not found')
        if (task.archivedAt !== undefined) throw new Error('archived task is read-only')
        // The lock belongs to an open execution, not to the column: a card
        // parked in 'running' by hand has no session and stays movable, while
        // a card the runner is executing cannot be moved out from under it.
        if (hasOpenExecution(task)) throw new Error('running task cannot be moved')
        if (!canMoveManually(task.status, action.status)) throw new Error('invalid manual status')
        this.document.tasks = this.document.tasks.map(item => item.id === action.taskId ? withStatus(item, action.status, now) : item)
        break
      }
      case 'archive': {
        if (this.subtreeHasOpenExecution(action.taskId)) throw new Error('running task cannot be archived')
        const result = applyArchiveTask(this.document.tasks, action.taskId, now, this.maxSubtaskDepth)
        if (!result.archived) throw new Error('task cannot be archived')
        this.document.tasks = [...result.tasks]
        break
      }
      case 'settle': {
        const task = this.document.tasks.find(item => item.id === action.taskId)
        if (task === undefined) throw new Error('task not found')
        if (task.archivedAt !== undefined) throw new Error('archived task is read-only')
        if (!task.executions.some(entry => entry.endedAt === undefined)) throw new Error('task has no open execution')
        // Force-close the executions this card governs. The verdict is
        // 'cancelled', never 'succeeded': a card whose execution produced no
        // evidence of a completed turn must not be recorded as finished work,
        // and a cancelled settlement returns the card to the todo column so the
        // operator can run it again. Nothing else clears a running card: move,
        // archive and delete all refuse one, which is what made a stuck card
        // unrecoverable from the board.
        const reason = 'execution closed manually by '
          + (initiator === undefined || initiator === '' ? 'the operator' : initiator)
          + ': no verdict was recorded'
        for (const member of cascadeTargets(this.document.tasks, action.taskId, this.maxSubtaskDepth)) {
          for (const execution of member.executions) {
            if (execution.endedAt !== undefined) continue
            this.document.tasks = this.document.tasks.map(item => item.id !== member.id
              ? item
              : settleExecution(item, execution.id, 'cancelled', now, reason))
          }
        }
        // Fold whatever became ready in the same action: an ancestor whose last
        // member this closed leaves the running column with it.
        this.finalizeReadyRuns(false)
        break
      }
      case 'restore': {
        if (this.subtreeHasOpenExecution(action.taskId)) throw new Error('running task cannot be restored')
        const result = applyRestoreTask(this.document.tasks, action.taskId, now, this.maxSubtaskDepth)
        if (!result.archived) throw new Error('task is not archived')
        this.document.tasks = [...result.tasks]
        break
      }
      case 'confirm-permission': {
        const task = this.document.tasks.find(item => item.id === action.taskId)
        if (task === undefined) throw new Error('task not found')
        if (task.permissionConfirmedAt !== undefined) break
        this.document.tasks = this.document.tasks.map(item => item.id === action.taskId
          ? { ...item, permissionConfirmedAt: now, updatedAt: now }
          : item)
        break
      }
      case 'rename-tag': {
        const result = applyRenameTag(this.document.tasks, action.from, action.to, now)
        if (result.error !== undefined) throw new Error(result.error)
        if (result.changed) this.document.tasks = [...result.tasks]
        break
      }
      case 'delete-tag': {
        const result = applyDeleteTag(this.document.tasks, action.name, now)
        if (result.error !== undefined) throw new Error(result.error)
        if (result.changed) this.document.tasks = [...result.tasks]
        break
      }
      case 'set-schedule': {
        const task = this.document.tasks.find(task => task.id === action.taskId)
        if (task?.archivedAt !== undefined) throw new Error('archived task is read-only')
        const result = applySetSchedule(this.document.tasks, action.taskId, action.patch, now, timeZone())
        if (!result.applied) throw new Error('invalid schedule')
        this.document.tasks = [...result.tasks]
        break
      }
      case 'rerun':
      case 'run': {
        const task = this.document.tasks.find(item => item.id === action.taskId)
        if (task?.archivedAt !== undefined) throw new Error('archived task is read-only')
        if (task === undefined || hasOpenExecution(task)) throw new Error('task is already running or missing')
        // The confirmation gate judges the RESOLVED binding: a subtask that
        // inherits an elevated permission from its parent is exactly as
        // unconfirmed as the parent would be without its own stamp.
        const refusal = this.bindingRefusal(task)
        if (refusal !== undefined) throw new Error(bindingRefusalMessage(refusal, this.sessionDefaultPermission, 'run'))
        runs = this.startCascade(task, now, initiator, action.kind === 'rerun')
        break
      }
    }
    // startCascade committed the opened participants itself; committing again
    // here would bump the revision twice for one action.
    if (runs === undefined || runs.length === 0) this.commit()
    return { state: this.state(), ...(runs === undefined ? {} : { runs }) }
  }

  /**
   * The binding that makes a run illegal, if any.
   *
   * A plain cascade launches one session per participant, so every participant
   * carries its own resolved binding and each one gates the run. A team run
   * launches only the Lead session: the Lead's binding gates it, and a
   * teammate inherits that session's permission, so a subtask's OWN pin is
   * refused exactly when the Lead session does not already carry it — the
   * teammate could never be given that authority, and dropping the pin
   * silently would misreport the work (an inherited binding is the Lead's own
   * and stays allowed once the Lead is confirmed).
   * @param root - the task being run.
   * @returns the first refusal, or undefined when the run may start.
   */
  private bindingRefusal(root: TaskRecord): { kind: 'root' | 'inherited' | 'subtask-pin'; title: string } | undefined {
    const participants = this.cascadeParticipants(root.id)
    if (root.teamRun === true) {
      const lead = participants.find(participant => participant.id === root.id)
      if (lead !== undefined && requiresPermissionConfirmation(lead, this.sessionDefaultPermission)) {
        return { kind: 'root', title: lead.title }
      }
      // The Lead session runs at the Lead's own binding, or at the deployment
      // default when it pins none; a teammate inherits that permission and
      // cannot be narrowed below it, so it carries a subtask pin when it is
      // already at least as wide. The raw record carries the subtask's OWN
      // binding: the resolved participant above already folded an inherited one
      // into its permission.
      const leadPermission = effectivePermission(lead ?? root) ?? this.sessionDefaultPermission
      const pinned = participants.find(participant => {
        if (participant.id === root.id) return false
        const raw = this.document.tasks.find(task => task.id === participant.id)
        return raw !== undefined && !permissionCarriedBy(leadPermission, effectivePermission(raw))
      })
      return pinned === undefined ? undefined : { kind: 'subtask-pin', title: pinned.title }
    }
    const unconfirmed = participants.find(participant => requiresPermissionConfirmation(participant, this.sessionDefaultPermission))
    if (unconfirmed === undefined) return undefined
    return { kind: unconfirmed.id === root.id ? 'root' : 'inherited', title: unconfirmed.title }
  }

  /**
   * The tasks a cascade from `rootId` would actually open executions for, with
   * their effective execution targets resolved. Archived members never run, and
   * a member that already has an open execution is skipped (a task cannot run
   * twice), so the result is the participant set the launch will use.
   */
  private cascadeParticipants(rootId: string): TaskRecord[] {
    return cascadeTargets(this.document.tasks, rootId, this.maxSubtaskDepth)
      .map(participant => resolveExecutionTargets(participant, this.document.tasks, this.maxSubtaskDepth))
      .filter(participant => participant.archivedAt === undefined
        && !hasOpenExecution(participant))
  }

  /** Whether a task or any of its subtasks still has an open execution. */
  private subtreeHasOpenExecution(id: string): boolean {
    return cascadeTargets(this.document.tasks, id, this.maxSubtaskDepth)
      .some(task => hasOpenExecution(task))
  }

  /**
   * Open one execution per cascade participant (the requested task and its
   * on-board descendants, within the depth limit) under a single run group, and
   * commit the ledger once. The returned runs are ordered root-first, so the
   * Host launches the parent before its subtasks.
   * @param root - the task the user ran.
   * @param now - clock instant (ms epoch).
   * @param initiator - the DSH session that asked for the run (audit only).
   * @param rerun - true to reset the root to 'todo' before starting it.
   * @param nextRunAt - when set, the root's schedule also rolls forward.
   */
  private startCascade(root: TaskRecord, now: number, initiator?: string, rerun = false, nextRunAt?: number): OpenedRun[] {
    const before = this.document.tasks
    const groupId = crypto.randomUUID()
    // A team-mode root runs as the Team Lead: every other member of the same
    // cascade is handed to that Lead as a teammate (the tree is flattened into
    // one Team, because only the Lead may spawn).
    const team = root.teamRun === true
    const started = new Map<string, TaskRecord>()
    const runs: OpenedRun[] = []
    for (const task of cascadeTargets(before, root.id, this.maxSubtaskDepth)) {
      if (task.archivedAt !== undefined) continue
      if (hasOpenExecution(task)) continue
      const base = rerun && task.id === root.id ? withStatus(task, 'todo', now) : task
      const opened = startExecution(base, now, crypto.randomUUID(), initiator, groupId)
      started.set(task.id, opened.task)
      runs.push({
        task: resolveExecutionTargets(opened.task, before, this.maxSubtaskDepth),
        execution: opened.execution,
        ...(team && task.id !== root.id ? { dispatch: 'teammate' as const } : {}),
      })
    }
    if (runs.length === 0) return []
    let tasks: readonly TaskRecord[] = before.map(task => started.get(task.id) ?? task)
    if (nextRunAt !== undefined) tasks = applyScheduleNextRun(tasks, root.id, nextRunAt, now, now)
    this.document.tasks = [...tasks]
    this.commit()
    return runs
  }

  /**
   * Finalize every cascade parent that is ready, walking from `taskId` up the
   * lineage: a member settles once its own outcome is recorded and none of its
   * group children is still open, and its verdict folds those children in
   * (failure dominates, then cancellation).
   */
  private settleCascade(taskId: string, groupId: string, now: number): boolean {
    let changed = false
    const visited = new Set<string>()
    let current: string | undefined = taskId
    while (current !== undefined && !visited.has(current)) {
      visited.add(current)
      const task: TaskRecord | undefined = this.document.tasks.find(item => item.id === current)
      if (task === undefined) break
      const execution = openGroupExecution(task, groupId)
      if (execution === undefined || execution.ownResult === undefined) break
      if (pendingCascadeChildren(this.document.tasks, current, groupId).length > 0) break
      const entries: Array<{ result: ExecutionOutcome; error?: string }> = [
        { result: execution.ownResult, ...(execution.ownError === undefined ? {} : { error: execution.ownError }) },
      ]
      for (const child of this.document.tasks) {
        if (child.parentId !== current) continue
        const childExecution = child.executions.find(entry => entry.runGroupId === groupId && entry.result !== undefined)
        if (childExecution?.result === undefined) continue
        entries.push({ result: childExecution.result, ...(childExecution.error === undefined ? {} : { error: childExecution.error }) })
      }
      const combined = combineCascadeOutcome(entries)
      this.document.tasks = this.document.tasks.map(item => item.id === current
        ? settleExecution(item, execution.id, combined.result, now, combined.error)
        : item)
      changed = true
      current = task.parentId
    }
    return changed
  }

  /**
   * Close every run that is already decided, and fold every lineage whose
   * members are all settled. The Host poll calls this on every tick, so a run
   * can no longer be left in the running column by a settle nobody observed:
   *
   * - A team run is governed by its Lead. Once the Lead's own outcome is
   *   recorded, its still-open members are settled with that verdict. A
   *   teammate is a durable member of the Team and may never report a turn of
   *   its own, and without this the whole lineage waits on it forever.
   * - A cascade parent whose members are all settled is finalized here even
   *   when the settle that completed the tree happened in another process, or
   *   was interrupted between its child write and its parent write.
   *
   * Idempotent: a run that is already folded is left untouched, so a caller may
   * invoke it on every tick.
   * @param persist - false to leave the document for the caller to commit.
   * @returns whether the document changed.
   */
  finalizeReadyRuns(persist = true): boolean {
    const now = this.now()
    let changed = false
    const groups = new Set<string>()
    for (const task of this.document.tasks) {
      for (const execution of task.executions) {
        if (execution.endedAt === undefined && execution.runGroupId !== undefined) groups.add(execution.runGroupId)
      }
    }
    for (const groupId of groups) {
      const lead = this.document.tasks.find(task => task.teamRun === true
        && task.executions.some(entry => entry.runGroupId === groupId))
      const verdict = lead === undefined ? undefined : this.leadVerdict(lead, groupId)
      if (lead !== undefined && verdict !== undefined
        && this.closeTeamMembers(lead.id, groupId, verdict.result, verdict.error, now)) changed = true
      // Fold the lineage: a member may itself be a parent of a deeper member.
      for (const task of this.document.tasks) {
        if (this.settleCascade(task.id, groupId, now)) changed = true
      }
    }
    if (changed && persist) this.commit()
    return changed
  }

  /**
   * The verdict a team run's Lead has already recorded: its own turn outcome
   * once that turn ended, or the folded outcome once its card settled.
   */
  private leadVerdict(lead: TaskRecord, groupId: string): { result: ExecutionOutcome; error: string | undefined } | undefined {
    const execution = lead.executions.find(entry => entry.runGroupId === groupId)
    const result = execution?.ownResult ?? execution?.result
    if (result === undefined) return undefined
    return { result, error: execution?.ownError ?? execution?.error }
  }

  /**
   * Settle every still-open member of a team run with the Lead's verdict.
   * A teammate that already reported its own outcome keeps it: the ordinary
   * fold still lets a failure dominate.
   * @param leadId - the Lead card's task id (never settled here).
   * @param groupId - the team run's group.
   * @param verdict - the Lead's outcome, inherited by members that never reported.
   * @param error - the Lead's failure text, inherited with a failed verdict.
   * @param now - clock instant (ms epoch).
   * @returns whether the document changed.
   */
  private closeTeamMembers(leadId: string, groupId: string, verdict: ExecutionOutcome, error: string | undefined, now: number): boolean {
    const members: string[] = []
    let recorded = false
    this.document.tasks = this.document.tasks.map(task => {
      if (task.id === leadId) return task
      const execution = openGroupExecution(task, groupId)
      if (execution === undefined) return task
      members.push(task.id)
      if (execution.ownResult !== undefined) return task
      recorded = true
      return {
        ...task,
        updatedAt: now,
        executions: task.executions.map(entry => entry.id === execution.id
          ? { ...entry, ownResult: verdict, ownError: error }
          : entry),
      }
    })
    let changed = recorded
    for (const memberId of members) {
      if (this.settleCascade(memberId, groupId, now)) changed = true
    }
    return changed
  }

  private repairSchedules(skipPast: boolean, persist = true): void {
    const now = this.now()
    let changed = false
    this.document.tasks = this.document.tasks.map(task => {
      const schedule = task.schedule
      if (schedule === undefined || !schedule.enabled) return task
      if (!skipPast && schedule.nextRunAt !== undefined) return task
      const next = nextRunAtMs(schedule.cron, now, scheduleZone(schedule))
      if (next === undefined) {
        changed = true
        this.document.scheduler.error = `invalid cron disabled for task: ${task.id}`
        return { ...task, schedule: { ...schedule, enabled: false, nextRunAt: undefined }, updatedAt: now }
      }
      if (schedule.nextRunAt === next) return task
      changed = true
      return { ...task, schedule: { ...schedule, nextRunAt: next }, updatedAt: now }
    })
    if (changed && persist) this.commit()
  }

  private reconcileInterruptedStarts(persist = true): void {
    const now = this.now()
    let changed = false
    const interrupted: Array<{ taskId: string; runGroupId: string | undefined }> = []
    this.document.tasks = this.document.tasks.map(task => {
      const execution = task.executions.at(-1)
      if (execution === undefined || execution.endedAt !== undefined || execution.sessionId !== undefined) return task
      changed = true
      interrupted.push({ taskId: task.id, runGroupId: execution.runGroupId })
      return settleExecution(task, execution.id, 'cancelled', now, 'host restarted before the execution session was recorded')
    })
    // A cancelled participant may have been the last pending child of a
    // deferred cascade parent; walking up from its parent is what lets that
    // parent finalize instead of staying in the running column forever.
    for (const entry of interrupted) {
      if (entry.runGroupId === undefined) continue
      const parentId = this.document.tasks.find(task => task.id === entry.taskId)?.parentId
      if (parentId !== undefined && this.settleCascade(parentId, entry.runGroupId, now)) changed = true
    }
    if (changed && persist) this.commit()
  }

  /**
   * Field-preserving migration of an older document. It first proves every task
   * row is structurally valid, so a document that would silently drop or coerce
   * rows fails loudly instead (no quarantined-empty restart), and then reuses
   * the current normalization.
   *
   * v4 adds `ScheduleRule.timeZone`. A rule written before v4 was evaluated in
   * whatever zone the Host process happened to report, so the migration stamps
   * that zone onto every enabled rule: the trigger instant is preserved exactly
   * (the stored `nextRunAt` already encodes the old zone), but the rule stops
   * following a later `TZ` change, which is what made an existing schedule
   * silently move when the Host's zone changed.
   *
   * v5 adds the per-execution acceptance block. The migration deliberately does
   * NOT stamp one: an execution opened before v5 keeps no contract, so it
   * settles on its own historical verdict and no in-flight run is retroactively
   * judged by a gate that was never armed for it.
   */
  private migrateLegacyDocument(parsed: ParsedLedgerDocument): LedgerDocument {
    if (!Array.isArray(parsed.tasks) || !parsed.tasks.every(row => isTaskRecord(row))) {
      throw new Error(`v${String(parsed.schemaVersion)} document contains structurally invalid task rows`)
    }
    // Every row passed `isTaskRecord` above, so the stamped rows are still
    // task records; the cast only re-narrows the unknown-typed on-disk array.
    const rows = (parsed.tasks as readonly unknown[]).map((value) => {
      const row = value as { schedule?: unknown }
      const schedule = row.schedule
      if (typeof schedule !== 'object' || schedule === null) return value
      if (typeof (schedule as { timeZone?: unknown }).timeZone === 'string') return value
      return { ...(value as object), schedule: { ...(schedule as object), timeZone: timeZone() } }
    })
    return this.normalizeDocument({ ...parsed, tasks: rows as TaskRecord[] })
  }

  /**
   * Find the still-open execution that ran in one session, with its task.
   *
   * The completion gate keys on the session id its tool call arrives from: the
   * execution record is the only object binding a session to a card, and an
   * already-settled execution is deliberately not returned (a session the board
   * no longer owns must not be gated).
   * @param sessionId - the DSH session the tool call runs in.
   * @returns the open execution and its task, or undefined.
   */
  findOpenExecutionBySession(sessionId: string): { task: TaskRecord; execution: ExecutionRecord } | undefined {
    if (sessionId === '') return undefined
    for (const task of this.document.tasks) {
      for (const execution of task.executions) {
        if (execution.endedAt !== undefined) continue
        if (execution.sessionId === sessionId) return { task, execution }
      }
    }
    return undefined
  }

  /**
   * Replace one execution's acceptance block (creating it when absent).
   *
   * A no-op when the serialized value is unchanged, so a coarse caller that
   * re-writes the same state never bumps the ledger revision. A settled
   * execution keeps its record: the report of a finished cycle must survive,
   * and only the board's own settlement moves the card.
   * @param taskId - the task owning the execution.
   * @param executionId - the execution to update.
   * @param verification - the new block.
   * @returns true when the ledger changed.
   */
  setVerification(taskId: string, executionId: string, verification: ExecutionVerification): boolean {
    const now = this.now()
    const task = this.document.tasks.find(item => item.id === taskId)
    const execution = task?.executions.find(entry => entry.id === executionId)
    if (task === undefined || execution === undefined) return false
    if (JSON.stringify(execution.verification ?? null) === JSON.stringify(verification)) return false
    this.document.tasks = this.document.tasks.map(item => item.id !== taskId ? item : {
      ...item,
      updatedAt: now,
      executions: item.executions.map(entry => entry.id === executionId ? { ...entry, verification } : entry),
    })
    this.commit()
    return true
  }

  private load(dir: string): LedgerDocument {
    const existed = existsSync(this.file)
    // schemaVersion stays unknown-typed here: on-disk documents may be v2 or
    // v3 (legacy), v4, or any future/invalid value the branches below sort out.
    let parsed: ParsedLedgerDocument
    try {
      parsed = JSON.parse(readFileSync(this.file, 'utf8')) as ParsedLedgerDocument
    } catch (error) {
      return this.recoverCorrupt(dir, existed, error)
    }
    if (typeof parsed.schemaVersion === 'number'
      && TASK_BOARD_MIGRATABLE_SCHEMA_VERSIONS.includes(parsed.schemaVersion)) {
      try {
        return this.migrateLegacyDocument(parsed)
      } catch (error) {
        // Migration failure is explicit: the original file stays in place
        // for manual recovery and the ledger refuses to start (fail closed).
        throw new Error(`ledger v${String(parsed.schemaVersion)} to v${TASK_BOARD_SCHEMA_VERSION} migration failed; original file kept at ${this.file}: ${error instanceof Error ? error.message : String(error)}`)
      }
    }
    try {
      if (parsed.schemaVersion !== TASK_BOARD_SCHEMA_VERSION || !Array.isArray(parsed.tasks)) throw new Error('unsupported ledger schema')
      return this.normalizeDocument(parsed)
    } catch (error) {
      return this.recoverCorrupt(dir, existed, error)
    }
  }

  private normalizeDocument(parsed: ParsedLedgerDocument): LedgerDocument {
    const tasks = parseHostTasks(parsed.tasks as readonly unknown[]).map(task => ({ ...task, executions: retainRecentExecutions(task.executions) }))
    const invalidScheduleIds = (parsed.tasks as unknown[]).flatMap(value => {
      if (typeof value !== 'object' || value === null) return []
      const row = value as { id?: unknown; schedule?: unknown }
      if (typeof row.schedule !== 'object' || row.schedule === null) return []
      const cron = (row.schedule as { cron?: unknown }).cron
      return typeof cron !== 'string' || !isValidCron(cron)
        ? [typeof row.id === 'string' ? row.id : 'unknown']
        : []
    })
    const documentLastTickAt = typeof parsed.scheduler?.lastTickAt === 'number' ? parsed.scheduler.lastTickAt : undefined
    const sidecarLastTickAt = this.readSchedulerSidecar()
    // A sidecar write can be newer than the last full commit (crash between
    // the two); lastTickAt only ever moves forward, so take the greater.
    const lastTickAt = sidecarLastTickAt === undefined || (documentLastTickAt !== undefined && documentLastTickAt >= sidecarLastTickAt)
      ? documentLastTickAt
      : sidecarLastTickAt
    return {
      schemaVersion: TASK_BOARD_SCHEMA_VERSION,
      revision: Number.isSafeInteger(parsed.revision) && (parsed.revision as number) >= 0 ? parsed.revision as number : 0,
      tasks,
      scheduler: {
        timeZone: timeZone(),
        ledgerId: typeof parsed.scheduler?.ledgerId === 'string' && parsed.scheduler.ledgerId !== '' ? parsed.scheduler.ledgerId : crypto.randomUUID(),
        ...(lastTickAt === undefined ? {} : { lastTickAt }),
        ...(typeof parsed.scheduler?.error === 'string' ? { error: parsed.scheduler.error } : {}),
        ...(invalidScheduleIds.length > 0 ? { error: `invalid cron disabled for task(s): ${invalidScheduleIds.join(', ')}` } : {}),
        ...(Array.isArray(parsed.scheduler?.importedSources) ? { importedSources: parsed.scheduler.importedSources.filter(x => typeof x === 'string') } : {}),
      },
      recentRequests: Array.isArray(parsed.recentRequests)
        ? parsed.recentRequests.flatMap((entry) => {
            if (typeof entry !== 'object' || entry === null) return []
            const request = entry as { requestId?: unknown; fingerprint?: unknown }
            return typeof request.requestId === 'string' && request.requestId !== '' && typeof request.fingerprint === 'string'
              ? [{ requestId: request.requestId, fingerprint: request.fingerprint }]
              : []
          }).slice(-MAX_REQUEST_CACHE)
        : [],
    }
  }

  /** Quarantine an unreadable document and start from an empty ledger. */
  private recoverCorrupt(dir: string, existed: boolean, error: unknown): LedgerDocument {
    if (existed) renameSync(this.file, `${this.file}.corrupt-${this.now()}-${process.pid}-${crypto.randomUUID()}`)
    mkdirSync(dir, { recursive: true })
    return {
      schemaVersion: TASK_BOARD_SCHEMA_VERSION,
      revision: 0,
      tasks: [],
      scheduler: { timeZone: timeZone(), ledgerId: crypto.randomUUID(), ...(existed ? { error: `corrupt ledger was quarantined: ${error instanceof Error ? error.message : String(error)}` } : {}) },
      recentRequests: [],
    }
  }

  private syncRecentRequests(): void {
    this.document.recentRequests = [...this.requestCache].map(([requestId, request]) => ({
      requestId,
      fingerprint: request.fingerprint,
    }))
  }

  private readSchedulerSidecar(): number | undefined {
    try {
      const parsed = JSON.parse(readFileSync(this.schedulerFile, 'utf8')) as { lastTickAt?: unknown }
      return typeof parsed.lastTickAt === 'number' && Number.isFinite(parsed.lastTickAt) ? parsed.lastTickAt : undefined
    } catch {
      return undefined
    }
  }

  /** Atomic write of the scheduler heartbeat sidecar (0600, tmp + rename + fsync). */
  private writeSchedulerSidecar(): void {
    const payload = JSON.stringify({ lastTickAt: this.document.scheduler.lastTickAt })
    mkdirSync(dirname(this.schedulerFile), { recursive: true })
    const tmp = `${this.schedulerFile}.tmp-${process.pid}`
    let fd: number | undefined
    try {
      fd = openSync(tmp, 'w', 0o600)
      writeFileSync(fd, payload, { encoding: 'utf8' })
      fsyncSync(fd)
      closeSync(fd)
      fd = undefined
      try { chmodSync(tmp, 0o600) } catch { /* Windows ACLs own access */ }
      renameSync(tmp, this.schedulerFile)
      try {
        const dirFd = openSync(dirname(this.schedulerFile), 'r')
        try { fsyncSync(dirFd) } finally { closeSync(dirFd) }
      } catch {
        // Windows does not permit fsync on a directory handle; rename remains atomic.
      }
    } catch (error) {
      if (fd !== undefined) closeSync(fd)
      try { unlinkSync(tmp) } catch { /* best-effort temporary cleanup */ }
      throw error
    }
    this.notify()
  }

  private commit(bumpRevision = true): void {
    if (bumpRevision) this.document.revision += 1
    mkdirSync(dirname(this.file), { recursive: true })
    const tmp = `${this.file}.tmp-${process.pid}`
    let fd: number | undefined
    try {
      fd = openSync(tmp, 'w', 0o600)
      writeFileSync(fd, JSON.stringify(this.document, null, 2), { encoding: 'utf8' })
      fsyncSync(fd)
      closeSync(fd)
      fd = undefined
      try { chmodSync(tmp, 0o600) } catch { /* Windows ACLs own access */ }
      renameSync(tmp, this.file)
      try {
        const dirFd = openSync(dirname(this.file), 'r')
        try { fsyncSync(dirFd) } finally { closeSync(dirFd) }
      } catch {
        // Windows does not permit fsync on a directory handle; rename remains atomic.
      }
    } catch (error) {
      if (fd !== undefined) closeSync(fd)
      try { unlinkSync(tmp) } catch { /* best-effort temporary cleanup */ }
      throw error
    }
    this.notify()
  }

  private notify(): void {
    for (const listener of [...this.listeners]) listener()
  }

  private acquireLock(): number {
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const fd = openSync(this.lockFile, 'wx', 0o600)
        const startedAt = ownProcessStartTimeMs()
        // Linux /proc and Windows PowerShell probes are ms-precise; locks they
        // write are compared strictly. Other POSIX probes (ps) stay
        // second-granularity, so their records are compared with the bounded
        // legacy tolerance.
        const probe = process.platform === 'linux' || process.platform === 'win32' ? 'exact' : 'legacy'
        writeFileSync(fd, JSON.stringify({ pid: process.pid, token: this.lockToken, startedAt, probe }), { encoding: 'utf8' })
        fsyncSync(fd)
        try { chmodSync(this.lockFile, 0o600) } catch { /* Windows ACLs own access */ }
        return fd
      } catch (error) {
        const code = (error as NodeJS.ErrnoException).code
        if (code !== 'EEXIST') throw error
        let pid: number | undefined
        let ownerStartedAt: number | undefined
        let ownerExact = false
        try {
          const owner = JSON.parse(readFileSync(this.lockFile, 'utf8')) as { pid?: unknown; startedAt?: unknown; probe?: unknown }
          if (typeof owner.pid === 'number') pid = owner.pid
          if (typeof owner.startedAt === 'number') ownerStartedAt = owner.startedAt
          ownerExact = owner.probe === 'exact'
        } catch {
          // A power-loss mid-write can leave an empty or truncated lock. Such a
          // lock still fails closed while it is fresh (a live owner may be
          // mid-write); once it is older than the grace window nothing can be
          // writing it, so the leftover is reclaimed instead of blocking every
          // later start until someone deletes it by hand (issue #1528).
          const age = (() => {
            try { return this.now() - statSync(this.lockFile).mtimeMs } catch { return Number.POSITIVE_INFINITY }
          })()
          if (age < UNREADABLE_LOCK_GRACE_MS) {
            throw new Error(`task-board ledger lock is unreadable: ${this.lockFile}; if this is a leftover from an unclean shutdown and no other DSH host is running, remove it manually and retry`)
          }
          try { unlinkSync(this.lockFile) } catch (unlinkError) {
            if ((unlinkError as NodeJS.ErrnoException).code !== 'ENOENT') throw unlinkError
          }
          continue
        }
        if (pid !== undefined && processIsAlive(pid)) {
          const actualStartedAt = pid === process.pid ? ownProcessStartTimeMs() : processStartTimeMs(pid)
          // A reused PID is exposed when the live process identity no longer
          // matches the recorded one: either the recorded start time differs
          // beyond the probe's resolution (strict for ms-precise 'exact'
          // records, a bounded legacy tolerance for old second-granularity
          // records written by ps), or (legacy locks without a start time)
          // the lock file predates the live process and therefore cannot
          // have been written by it. Takeover is safe in both cases — the
          // original owner is gone.
          const staleReuse = actualStartedAt !== undefined && (
            ownerStartedAt !== undefined
              ? startTimeMismatch(ownerStartedAt, actualStartedAt, ownerExact)
              : (() => {
                try { return statSync(this.lockFile).mtimeMs < actualStartedAt } catch { return true }
              })()
          )
          if (!staleReuse) {
            const confirmedOwner = ownerStartedAt !== undefined && actualStartedAt !== undefined && !startTimeMismatch(ownerStartedAt, actualStartedAt, ownerExact)
            const hint = confirmedOwner
              ? ''
              : `; if this PID was reused after a crash and no other DSH host is running, remove ${this.lockFile} manually and retry`
            throw new Error(`task-board ledger is already owned by process ${pid}${hint}`)
          }
        }
        try { unlinkSync(this.lockFile) } catch (unlinkError) {
          if ((unlinkError as NodeJS.ErrnoException).code !== 'ENOENT') throw unlinkError
        }
      }
    }
    throw new Error(`task-board ledger lock could not be acquired: ${this.lockFile}`)
  }
}
