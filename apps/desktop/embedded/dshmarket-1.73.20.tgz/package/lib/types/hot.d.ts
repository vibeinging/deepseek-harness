/**
 * Restart-free installs: mount a freshly installed plugin into the running
 * composition through a market-owned Include subtree.
 *
 * Durable state stays with the profile's `dsh.profile.bundles` (reconciled by
 * the dsh CLI at install time), so the next boot loads the plugin through the
 * normal bundle layer. The subtree here exists only for the current process:
 * its input files live under `<profile>/.dsh-market/` and are wiped on every
 * boot, so a crash can never leave a file that collides with the bundle layer
 * (inserting an id the bundle layer also inserts is a hard boot failure).
 * `state.json` in the same directory is the market's own durable state
 * (disable list + custom groups) and deliberately survives the wipe.
 *
 * The Include subclass suppresses `write()` — the loader otherwise persists
 * tree changes back to the file it read (see dsh's agent-presets PresetTree
 * for the in-tree precedent).
 */
import { type UpdateCheckIntervalHours } from './update-notification-settings.ts';
import { type Channel } from './channels.ts';
import { type Region } from './regions.ts';
interface HotRow {
    id: string;
    name: string;
}
interface PluginHandle {
    await(): Promise<unknown>;
    dispose(): Promise<unknown> | void;
}
/** One structured record delivered to a host logger exporter (cordis `Message`). */
interface HostLogMessage {
    name?: unknown;
    type?: unknown;
    args?: unknown;
}
/**
 * Sink shape accepted by cordis' `LoggerService.exporter`.
 *
 * `levels` is not optional decoration: the service skips a record before it
 * ever reaches `export` when
 * `(levels[name] ?? levels.default ?? logger.level ?? 1) < record.level`.
 * The default threshold is `1`, and `warn` is level `2` — a sink that leaves
 * `levels` out never sees a single warning.
 */
interface HostLogSink {
    levels?: Record<string, number>;
    export(message: HostLogMessage): void;
}
interface HotContext {
    plugin(plugin: unknown, config: unknown): PluginHandle;
    logger?: {
        info?(message: string): void;
        warn(message: string): void;
        /**
         * Optional structured sink: cordis' `LoggerService.exporter` hands over
         * every record the process logs and returns a disposer. Absent on hosts
         * whose logger is a bare object, and on test doubles.
         */
        exporter?(sink: HostLogSink): unknown;
    };
}
/**
 * Profile-scoped resolution for hot-mount imports: turn a bare package name into
 * the absolute `file://` entry URL of the package just installed into
 * `profileDir`.
 *
 * Include-tree rows reach `Include.import` as BARE names (`name:
 * '@scope/pkg'`), and the base class resolves them against the LOADER's own
 * location — the host closure
 * (`closures/<fp>/node_modules/…/cordis-plugin-loader`), whose parent walk
 * can never reach `home/profiles/<profile>/node_modules/`. Under a host whose
 * loader sits in an immutable dependency closure, EVERY market hot mount dies
 * with `Cannot find module '<pkg>' from '…/cordis-plugin-loader/…'` and falls
 * back to "restart required", blaming the plugin for what is a resolution
 * anchor problem.
 *
 * Resolving the module at import time, against the profile it was actually
 * installed into, is anchor-independent: `require.resolve` walks
 * `profileDir/node_modules` natively, so the tree hands the loader a
 * `file://` URL needing no further resolution. Non-bare specifiers (relative
 * paths, `file://`, `cordis:` builtins) and names that do not resolve under
 * the profile pass through unchanged, preserving base-class semantics for
 * every shape this fix does not own.
 *
 * The fallback keeps the name bare rather than synthesising a URL: a package
 * whose entry cannot be located via `require.resolve` (no `main`/exports —
 * the market's own `entryArtifactExists` heuristic covers those shapes before
 * an install is accepted) is not something this resolver should guess about.
 * Client-only shims never reach this function: their import returns a no-op
 * host module before attempting package resolution.
 */
export declare function resolveProfileEntry(profileDir: string, name: string): string;
/**
 * Insert rows of a plugin's bundle patch, or null when the patch contains
 * anything beyond plain `id`/`name` insert rows (config blocks, disables,
 * expressions) — those compositions fall back to restart activation.
 */
export declare function parseSimplePatch(patchText: string): HotRow[] | null;
/**
 * Which shape stopped `parseSimplePatch` — the CAUSE, not just "not plain".
 *
 * `parseSimplePatch` collapses five different inputs into one `null`: a
 * `config` block, a `disabled`/`enabled` switch row, any other key (`inject`,
 * a nested mapping), a row whose `name` never arrives, and a patch with no
 * insert rows at all. Every caller that had to explain the refusal threw all
 * five into one sentence written for the first, and told users their patch
 * "contains config/expression rows" when it merely switched a row off
 * (#1102). Naming the shape is the difference between a sentence the reader
 * can act on and one they cannot (#813, AGENTS.md: 说不出来就别用一句话把
 * 空缺填上).
 */
export type PatchBlocker = 'config' | 'disabled' | 'incomplete' | 'empty' | 'other';
export interface PatchScan {
    /** Insert rows read before the scan stopped; empty when it did not. */
    rows: HotRow[];
    /** null when the patch IS a plain insert list (`rows` is then non-empty). */
    blocker: PatchBlocker | null;
    /** The key that stopped the scan, when there is one to name. */
    key?: string;
}
export declare function scanPatch(patchText: string): PatchScan;
/**
 * One sentence for a refusal that is only about the patch's shape, naming the
 * cause and what happens next. Shared by the hot mount and the activation
 * verdict so the two cannot drift apart on the same fact again.
 */
export declare function patchBlockerReason(blocker: PatchBlocker, key?: string): string;
/**
 * Wipe leftover hot-mount inputs; call once when the market host starts.
 * `state.json` (disable choices + groups) deliberately survives.
 */
export declare function cleanHotDir(profileDir: string): void;
/** Persisted market state: the generic disable list plus custom groups. */
export interface MarketState {
    /** Plugins the user switched off; replayed at every boot. */
    disabled: Set<string>;
    /** User-defined plugin groups: group name → member package names. */
    groups: Record<string, string[]>;
    /** Display order of group names; "ungrouped" is implicit and never listed. */
    groupOrder: string[];
    /**
     * The user's own one-line note per installed plugin (#347).
     *
     * A catalog description answers "what is this", written by its author for
     * strangers and often in a language the reader did not pick. It cannot
     * answer "why did I install this" — which is the question someone with
     * forty plugins is actually asking. So a note REPLACES the description on
     * that row, and the original stays one click away.
     *
     * Local state like the disable list and the groups beside it: never sent
     * anywhere, and carried by a backup because it is part of how this profile
     * is set up.
     *
     * Optional on the way IN: several callers build a state object from the
     * few fields they own and hand it to writeMarketState. Requiring this one
     * would make every such call a silent way to erase every note — the exact
     * shape of #339, where a partial snapshot dropped a field nobody was
     * thinking about. Omitting it means "leave them alone" instead.
     */
    notes?: Record<string, string>;
    /**
     * The release channel the user PICKED, absent until they pick one.
     *
     * Absent is not the same as 'stable': with no choice on record the channel
     * is derived from the running build, so installing a prerelease by hand
     * puts you on the beta channel without a second step. Once chosen, the
     * choice is the answer — including "stable" while a beta is running, which
     * is how someone gets back off the channel.
     */
    channel?: Channel;
    /**
     * The download region in force, absent until something has decided one.
     *
     * Absent means "nobody has decided yet", which is what triggers the
     * one-time network probe. Once a value is here — whether the probe wrote
     * it or the user picked it — no further probing happens, so the market
     * does not silently change routes between runs.
     */
    region?: Region;
    /**
     * Whether `region` was chosen by the probe rather than by the user.
     *
     * Only drives a one-time notice explaining why the market picked what it
     * picked. A user who never learns a route was chosen for them has no way
     * to know the setting exists, and no reason to look for it when something
     * downloads oddly.
     */
    regionAuto?: boolean;
    /**
     * Catalog entry URLs the user bookmarked for later install (#414).
     * Keys are registry `url` strings, not package names — favorites are a
     * pre-install list, unlike groups/notes which target installed packages.
     */
    favorites?: string[];
    /**
     * Package names the user hid from Discover and Themes (#657).
     *
     * Local, per-profile, reversible. The Hidden tab lists the same names so
     * the choice can be undone. Independent of `disabled` (the plugin can keep
     * running) and of the session-only update ignore (that one dies on restart).
     * A stored name may be the installed package name or the catalog package
     * name; the client treats both as one plugin when it can match them.
     *
     * Optional on the way in, like `notes` / `favorites`: several callers
     * build a state object from the few fields they own, and requiring this
     * one would make every such call a silent way to erase the list (#339).
     */
    blocked?: string[];
    /**
     * Installed package names the user asked not to be reminded about (#728).
     *
     * This is not {@link blocked}. Hiding a plugin takes it off Discover.
     * This list leaves the plugin where it is, and leaves the update itself
     * on the installed row. It only stops the reminder: the badge, the
     * "update all" count, the sort-to-top, and the reminder bar. A new
     * version is still listed, and the row's own Update button still works.
     *
     * Optional on the way in, for the same reason as `blocked` (#339).
     * An empty array is how the last name is removed.
     */
    updateExempt?: string[];
    /** Background update checks run only after an explicit opt-in. */
    backgroundUpdateChecks?: boolean;
    /** Polling cadence; absent or invalid legacy values use the six-hour default. */
    backgroundUpdateIntervalHours?: UpdateCheckIntervalHours;
    /** User-supplied HTTPS prefix used when the built-in GitHub routes fail. */
    githubProxy?: string;
    /**
     * Whether the market also opens from its own row in the sidebar (#846).
     *
     * Off unless the user turned it on: the sidebar's global rows are the
     * host's own pages, and installing plugins is occasional, so a row nobody
     * asked for would be a permanent fixture for an occasional task. The page
     * entries are the defaults, and the last-door rule (#1015) — enforced by
     * the route — is what keeps turning this off from leaving the market
     * unreachable.
     *
     * Omission preserves, an explicit value wins — the githubProxy contract,
     * because turning it off has to be expressible.
     */
    sidebarEntry?: boolean;
    /**
     * Whether the market still lists its own page in Settings (#1015).
     *
     * Absent means shown. Only an explicit `false` is stored, unlike
     * `sidebarEntry`: this entry has always been on, and every host before
     * 0.2.1 offers it as the only door, so an absent field is the ordinary
     * case rather than an unanswered question. Turning it back on clears the
     * field so a later default change still reaches users who never touched it.
     */
    settingsSection?: boolean;
    /**
     * Whether the market still adds its tab to the host's Plugins page
     * (#1015). Absent means shown, on the same contract as
     * {@link settingsSection}.
     *
     * A host that never declares the slot has no tab to hide; the saved
     * answer is kept for the hosts that do.
     */
    pluginsTab?: boolean;
    /**
     * Packages the market removed from the profile's own declarations because
     * the build on disk can no longer compose (#663).
     *
     * The case this exists for: an update blocked by open files leaves the
     * target directory incomplete, `keepLockedBuild` cannot keep the previous
     * build, and the profile goes on declaring a package whose `package.json`
     * is missing. The next start dies in composition — on Desktop the window
     * never opens — and the only way out was uninstalling the plugin by hand.
     * So the declaration is dropped instead (a rename or a delete of the
     * directory itself cannot be attempted: the same lock that stopped pnpm
     * refuses the market's move too), and this map is what keeps that from
     * being silent. The plugin disappears from the installed list; this is the
     * record saying why, and what spec to reinstall.
     *
     * Optional on the way in, like `notes`: several callers write a state
     * object built from the few fields they own, and requiring this one would
     * make every such call a way to erase every entry (#339's shape).
     */
    brokenPlugins?: Record<string, BrokenPlugin>;
    /**
     * The operator's pinned build environment (issue #336) as saved from the
     * market's own settings card. Absent means "the composition says" — the
     * entry's `config.buildEnv`, or nothing at all. Present (non-empty) means
     * a saved editor state REPLACES the composition map, so clearing the
     * field on the card inherits the composition again rather than freezing
     * an earlier save. Read live into `config.buildEnv` by the routes; see
     * src/dsh-cli.ts spawnEnv for the precedence once it reaches a child.
     */
    buildEnv?: Record<string, string>;
    /**
     * When this market installed or last updated each package (#1142/#1121).
     *
     * A row in the installed list has no time of its own. `node_modules/<pkg>`
     * mtime is not one (pnpm rewrites it on every install, so a batch all
     * shares one instant) and `.plugin-manager/logs/operation-*` is a log with
     * a retention policy, not a field. So the market writes its own stamps at
     * the two moments it knows: an install it ran, and an update that landed.
     *
     * Two consequences worth stating in the shape itself:
     * - A package installed anywhere else (the CLI, the host's plugins page) has
     *   no entry, and displaying a guessed one would be worse than displaying
     *   nothing: "按安装时间排" would then be an ordering of guesses.
     * - Keys carry no profile: the file is per profile already, and a copied
     *   profile inheriting another's timestamps would be inventing history.
     */
    installTimes?: Record<string, InstallTimes>;
}
/** One package's market-recorded timestamps, both ISO 8601. */
export interface InstallTimes {
    /** When this market installed the package. Absent when it did not. */
    installedAt?: string;
    /** When an update of it last landed. Absent when it never updated here. */
    updatedAt?: string;
}
/** Why a package is no longer declared, and what to put back. */
export interface BrokenPlugin {
    /** The dependency spec it had before removal — the reinstall target. */
    spec: string;
    /**
     * Machine-readable cause; the UI owns the wording. `locked`: pnpm reported
     * the open-file refusal. `cancelled`: the user cancelled while pnpm was
     * replacing the directory — the result is the same empty shell, but no cause
     * was observed, so the notice must not name one (#663).
     */
    reason: BrokenReason;
    /** When the market removed the declaration (ISO 8601). */
    at: string;
}
export type BrokenReason = 'incomplete-build-locked' | 'incomplete-build-cancelled';
/** Upper bound on bookmarked catalog URLs kept in state.json (#414). */
export declare const MAX_FAVORITES = 500;
/** Upper bound on blocked package names kept in state.json (#657). */
export declare const MAX_BLOCKED = 500;
/** Upper bound on the persistent do-not-remind list (#728). */
export declare const MAX_UPDATE_EXEMPT = 500;
/** npm package names are at most 214 characters. Longer values are not names. */
export declare const MAX_BLOCKED_NAME = 214;
/**
 * Upper bound on the install-time map (#1142). One entry per package the
 * market itself installed, and a profile with 500 of those is already an
 * outlier; the cap keeps state.json from growing with every plugin the user
 * ever tried and removed.
 */
export declare const MAX_INSTALL_TIMES = 500;
/**
 * Sanitize an untrusted build-env map (state.json, or the card route's body)
 * into the shape spawnEnv can merge.
 *
 * An empty map and a non-object both read as undefined: clearing the card
 * must inherit the composition, and a blank line in state.json must not
 * disable every pinned variable. Only the merge precedence in
 * src/dsh-cli.ts spawnEnv — never this — protects PATH and CI, but a value
 * a user typed for them would silently do nothing there, so it is rejected
 * here with a reason instead.
 *
 * `GIT_ASKPASS` and `SSH_ASKPASS` are deliberately NOT rejected, though they
 * are the two names that can re-open a credential prompt: pointing them at a
 * program is the supported non-interactive way to answer one, and #587/#596
 * close the *terminal* fallback (GIT_TERMINAL_PROMPT, BatchMode) rather than
 * the program one. A user who pins these has already said where the answer
 * comes from; a user who does not still gets the closed prompt.
 */
export declare function buildEnvFromUnknown(value: unknown): Record<string, string> | undefined;
/**
 * Read the whole market state. Legacy `disabledSkins` (the pre-#60
 * theme-only key) still loads; every new write uses the generic `disabled`
 * key (#60).
 */
/** A note is a label, not a document: one line, bounded so state.json cannot
 * grow without limit from a paste. */
export declare const MAX_NOTE = 200;
export declare function readMarketState(profileDir: string): MarketState;
/**
 * Persist the whole market state.
 *
 * Every field a caller does not carry forward is taken from disk rather than
 * dropped. Several callers legitimately know about only one part of the
 * state — `writeMarketState(dir, { disabled, groups, groupOrder })` appears
 * at five call sites in routes.ts — and before #435 that shape silently
 * erased whatever else the user had chosen:
 *
 * - `channel` and `region` had no fallback at all, so toggling any plugin
 *   threw away the user's update channel and download region. Both are
 *   deliberate choices made through the settings card, and neither has a
 *   "clear it" path: once picked they only ever move to another value. So
 *   an absent one always means "the caller has nothing to say", never
 *   "the user unchose it".
 * `notes` keeps its original rule — an explicit object wins, including an
 * empty one, because deleting the last note has to be expressible. What made
 * #435 lose notes was not this function but a caller: the note route wrote
 * through a fresh read while the long-lived `marketState` in routes.ts still
 * carried `notes: {}` from boot, and the next write from that object put the
 * empty one back. The fix for that belongs at the call site, where the two
 * copies are, not here — see the note route.
 *
 * Reading before writing costs one small JSON parse on an operation that is
 * already doing filesystem work, and it is what makes "this function writes
 * the whole document" safe for callers that only hold part of it.
 */
export declare function writeMarketState(profileDir: string, state: MarketState): void;
/** Plugins the user switched off; skipped by the boot re-mount. */
export declare function readDisabled(profileDir: string): Set<string>;
/** Persist just the disable list, preserving groups and order. */
export declare function writeDisabled(profileDir: string, disabled: Set<string>): void;
/** @deprecated theme-specific alias — kept for pre-#60 callers. */
export declare function readDisabledThemes(profileDir: string): Set<string>;
/** @deprecated theme-specific alias — kept for pre-#60 callers. */
export declare function writeDisabledThemes(profileDir: string, disabled: Set<string>): void;
/**
 * The market installed these packages just now (#1142): both stamps are this
 * moment, because the first install is also the last change so far.
 */
export declare function recordInstalled(profileDir: string, names: readonly string[], at?: Date): void;
/**
 * An update of these packages landed: only the update stamp moves.
 *
 * A package with no entry keeps `installedAt` absent — the market never saw
 * it installed, and "when I first noticed it" is a different fact. Writing it
 * here would make the sort report a guessed install order as history.
 */
export declare function recordUpdated(profileDir: string, names: readonly string[], at?: Date): void;
/** The package is gone: its stamps must not outlive it. */
export declare function forgetInstalled(profileDir: string, name: string): void;
/** Package names whose hot-mount trees are still attached and can be removed. */
export declare function listHotMounts(): string[];
/** Report a failed child only when it belongs to this package's hot-mount tree. */
export declare function hotMountFailure(packageName: string, profileDir?: string): string | null;
/** Hot mounts the market can report as live. */
export declare function listLiveHotMounts(): string[];
/** Outcome of one hot-mount attempt; `reason` explains non-`ok` results. */
export interface HotMountResult {
    ok: boolean;
    /** Bilingual reason shown to the user instead of a bare restart banner. */
    reason: string | null;
    /** The tree is still attached so its running components can continue. */
    retained?: true;
    /**
     * Set when nothing was attempted because this package can only come up on a
     * start — its patch holds more than plain inserts. That is a verdict about
     * the package, not a mount that crashed: the durable switch can still be
     * written, where a crash must not be persisted (#575, #1010).
     */
    deferred?: true;
}
/**
 * Dispose a plugin hot-mounted earlier in this session, removing it from the
 * running composition immediately.
 * @param packageName - package to unmount.
 * @returns true when a live hot mount was found and disposed.
 */
export declare function hotUnmount(packageName: string): Promise<boolean>;
/**
 * Mount `packageName` (just installed into the profile) into the running
 * composition.
 * @param ctx - market host context; the subtree unwinds with the market's fiber.
 * @param profileDir - profile the package was installed into.
 * @param packageName - installed package to activate.
 * @returns whether the plugin is live without a restart, plus the reason
 * when it is not (P0-2: the UI must distinguish "restart will fix it" from
 * "this package can never hot-mount").
 */
export declare function hotMount(ctx: HotContext, profileDir: string, packageName: string): Promise<HotMountResult>;
/**
 * Mount every installed client-only package (`dsh.client` without
 * `dsh.bundle`) at market startup. The bundle reconcile skips these packages
 * entirely, so without the market's shim their client bundles are unreachable
 * in every boot — this is what makes them behave like normal plugins.
 * @returns names that were mounted.
 */
export declare function mountClientOnlyDeps(ctx: HotContext, profileDir: string, 
/** The host's install directory; `undefined` finds it, `null` means "do not look". */
hostDirectory?: string | null): Promise<string[]>;
/**
 * Package names the profile's OWN bundle layer already mounts.
 *
 * The shim predicate reads the profile manifest, so it can only see a package
 * as a dependency; it cannot see that an in-box bundle mounts the same package
 * under a row id of its own — `@deepseek-ai/dsh-web-app` ships
 * `- id: connection` / `name: '@deepseek-ai/dsh-client-connection'` (#1137).
 * Those packages also declare `dsh.client` and no `dsh.bundle`, so every
 * existing predicate says "shim it". Only the row NAMES link the two, and a
 * clean profile's bundles are the only place they are written down.
 *
 * A bundle whose declaration cannot be read contributes nothing, which keeps
 * today's behaviour (shim, possibly duplicated) rather than silently dropping
 * a client bundle that the bundle layer never mounts.
 */
export declare function bundleLayerTargets(profileDir: string, bundles: Iterable<string>, hostDirectory?: string | null): Set<string>;
/**
 * Row ids and package names the user's own patch layer (cordis.patch.yml)
 * already contains. Line-wise scan on purpose: the file may hold structures
 * the market's strict patch parser rejects, but any mention of a row id or
 * package name is enough to know the user manages it (#58).
 */
export declare function readUserPatchControls(profileDir: string): {
    ids: Set<string>;
    names: Set<string>;
};
/**
 * Whether the user patch layer manages `name` — matched by exact package
 * name or by the plugin-manager row-id convention (strip the leading @,
 * non-alphanumerics to '-', lowercase).
 */
export declare function patchLayerManages(controls: {
    ids: Set<string>;
    names: Set<string>;
}, name: string): boolean;
/**
 * Delete the market's own state directory.
 *
 * `cleanHotDir` wipes the ephemeral hot-mount inputs on every boot but
 * deliberately preserves `state.json` — the disable list and custom groups
 * are the user's durable choices. Uninstalling the market is the one moment
 * where removing them is the right thing, and only when the user asked.
 * @returns true when a directory was there to remove.
 */
export declare function purgeMarketState(profileDir: string): boolean;
export {};
