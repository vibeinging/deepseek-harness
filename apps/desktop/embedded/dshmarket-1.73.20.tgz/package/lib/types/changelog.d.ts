/**
 * Update notes: what changed between an installed version and HEAD.
 *
 * Every byte of GitHub data comes from the catalog side's daily probe,
 * published as the `dsh-plugin-updates` package (origin fallback
 * `updates.json` beside `plugins.json`). The market asks GitHub for nothing:
 * anonymous REST quota is shared per egress IP and already unreliable behind
 * common proxies, and this data is wanted by thousands of markets but
 * produced perfectly well once a day by one probe.
 *
 * What the catalog cannot know is where each user's installed version sits,
 * so slicing the commit tail at that boundary happens here: the same sha the
 * update check resolved (`current`) marks where "new" begins. A tail that
 * does not contain it means the range is wider than the tail — those are
 * labelled recent commits rather than pretending to be an exact interval.
 * npm installs with neither notes nor commits fall back to npm publish times,
 * and a plugin nothing answers for gets a neutral "no notes" — absence of
 * release notes is the ordinary condition of small plugins, not a defect.
 * A plugin installed from any other source the notes hold nothing for gets
 * `source` instead: its history is where it came from, and the market says
 * it has none on hand rather than that the plugin publishes none (#819).
 */
export interface ReleaseNotes {
    tag: string | null;
    name: string | null;
    publishedAt: string | null;
    url: string | null;
    body: string;
}
export interface CommitNote {
    sha: string;
    message: string;
    date: string | null;
}
interface UpdatesEntry {
    release?: ReleaseNotes | null;
    commits?: CommitNote[];
}
interface UpdatesPayload {
    count?: number;
    updates?: Record<string, UpdatesEntry>;
}
/**
 * The update-notes payload from whichever route the region serves.
 *
 * Same source order as the catalog itself — the npm package first where one
 * exists (its mirror reach is the reason the package exists), then the
 * origin. Version-keyed like the catalog too: an unchanged payload costs one
 * packument read per TTL, not a tarball.
 */
export declare function loadUpdateNotes(force?: boolean): Promise<UpdatesPayload>;
/** Drop the cached payload (nothing currently invalidates it mid-process). */
export declare function invalidateUpdateNotes(): void;
/**
 * Slice the commit tail at the installed sha.
 *
 * @returns the commits newer than `installed`, and whether the boundary was
 *   actually found — `found === false` means the range is wider than the tail
 *   (or history diverged), so callers must label the result "recent" rather
 *   than exact.
 */
export declare function sliceCommitsAt(items: CommitNote[], installed: string | null): {
    items: CommitNote[];
    found: boolean;
};
/**
 * The version a release tag names, when it names one.
 *
 * Tags come as `v1.2.3`, `1.2.3`, `@scope/pkg@1.2.3` or `pkg-v1.2.3`; the
 * FIRST semver-shaped run is the version in all of them. A tag that names no
 * version (`nightly`) returns null, and callers must treat "unknown" as "do
 * not judge" rather than "older".
 */
export declare function releaseVersionOf(tag: string | null): string | null;
/** The repo url key an entry's update notes live under, or null. */
export declare function repoKeyOf(spec: string): string | null;
/**
 * The web page of the repository a git spec installs from, or null.
 *
 * What the dialog can point at when the market cannot read a source's notes
 * itself. The owner/repo casing is kept: not every host matches paths
 * case-insensitively the way GitHub does.
 */
export declare function sourceWebUrl(spec: string): string | null;
/**
 * Look an entry up by its catalog url.
 *
 * The catalog keys entries by the url as listed (author's casing preserved);
 * the market resolves repos to lowercase (as every other consumer of
 * `repoOfTarget` sees them). Match case-insensitively so the two sides never
 * disagree over a capital letter.
 */
export declare function entryForRepo(payload: UpdatesPayload, key: string): UpdatesEntry | undefined;
export declare function npmPublishTimes(name: string): Promise<{
    version: string;
    date: string;
}[]>;
/** Everything the dialog renders for one plugin, already resolved. */
export interface UpdateNotes {
    kind: 'release' | 'commits' | 'npm' | 'source' | 'none';
    /** Present for `release`: the author's own notes for the latest release. */
    release?: ReleaseNotes;
    /** Present for `commits`: the tail, sliced when the boundary was found. */
    commits?: {
        items: CommitNote[];
        found: boolean;
    };
    /** Present for `npm`: recent versions with their publish dates. */
    npmTimes?: {
        version: string;
        date: string;
    }[];
    /** Present for `source`: the repository page to read changes on, or null. */
    sourceUrl?: string | null;
    /**
     * Present for `release` when the notes describe a version NEWER than the
     * one the Update button installs (#1193): the snapshot is the repository's
     * latest release, while the target may be an older, already installable
     * one. Carries that target so the dialog can say whose notes these are.
     */
    beyondTarget?: string;
    /**
     * Present for `source`: `missing` when the notes loaded without this
     * plugin, `unavailable` when they could not be loaded at all — a passing
     * failure, not a fact about the plugin — and `unreadable` when the source is
     * one the market can never read, so waiting will not help (#819).
     */
    reason?: 'missing' | 'unavailable' | 'unreadable';
}
/**
 * Resolve the notes for one installed plugin, or `{ kind: 'none' }`.
 *
 * Never throws: every failure along the way degrades to the next tier, the
 * same contract the issue promised — a dialog that cannot load its data shows
 * a neutral statement, not an error.
 */
export declare function updateNotesFor(profile: string, explicitDir: string | undefined, name: string, 
/** The version the Update button installs, when it is not simply "latest". */
target?: string): Promise<UpdateNotes>;
export {};
